// liblegato needs a COMPONENT_INIT to pull in libs

#include "legato.h"
COMPONENT_INIT
{
}

