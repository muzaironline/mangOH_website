/**
 * @file
 *
 * <HR>
 *
 * Copyright (C) Sierra Wireless, Inc. Use of this work is subject to license.
 */

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "interfaces.h"
#include "bridge.h"


