#include "../inc/common.h"

int resolve_address(const char *host, const char *service, coap_address_t *dst)
{
    struct addrinfo hints, *res;
    int error, len = -1;

    memset(&hints, 0, sizeof(hints));
    memset(dst, 0, sizeof(*dst));
    hints.ai_socktype = SOCK_DGRAM;
    hints.ai_family = AF_UNSPEC;

    error = getaddrinfo(host, service, &hints, &res);
    if (error != 0)
    {
        LE_ERROR("getaddrinfo: %s", gai_strerror(error));
        return error;
    }

    while (res)
    {
        if (res->ai_family == AF_INET6 || res->ai_family == AF_INET)
        {
            len = dst->size = res->ai_addrlen;
            memcpy(&dst->addr.sin6, res->ai_addr, dst->size);
            goto finish;
        }
        res = res->ai_next;
    }

finish:
    freeaddrinfo(res);
    return len;
}

/**
 * @brief split a string based on a separator
 *
 * @param str the string to be splited
 * @param sep the separator for the string
 * @return char** a string array with the result
 */
char **str_split(char *str, const char sep)
{
    char **result = NULL;
    size_t count = 0;
    char *tmp = str;
    char *last_sep = NULL;
    char delim[2];
    delim[0] = sep;
    delim[1] = 0;

    while (*tmp)
    {
        if (sep == *tmp)
        {
            count++;
            last_sep = tmp;
        }
        tmp++;
    }

    count += last_sep < (str + strlen(str) - 1);
    count++;
    result = malloc(sizeof(char *) * count);
    if (!result)
        return result;

    size_t idx = 0;
    char *token = strtok(str, delim);
    while (token)
    {
        assert(idx < count);
        *(result + idx++) = strdup(token);
        token = strtok(0, delim);
    }
    assert(idx == count - 1);
    *(result + idx) = 0;

    return result;
}