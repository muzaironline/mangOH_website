#ifndef __COMMON__H__
#define __COMMON__H__

#include "legato.h"

#include <netdb.h>
#include <sys/socket.h>

#include "libcoap.h"
#include "coap_forward_decls.h"
#include "block.h"
#include "address.h"
#include "async.h"
#include "coap_cache.h"
#include "coap_dtls.h"
#include "coap_event.h"
#include "coap_io.h"
#include "coap_prng.h"
#include "option.h"
#include "subscribe.h"
#include "coap_time.h"
#include "encode.h"
#include "mem.h"
#include "net.h"
#include "pdu.h"
#include "resource.h"
#include "str.h"
#include "uri.h"

#include "coap_debug.h"

int resolve_address(const char *host, const char *service, coap_address_t *dst);
char **str_split(char *str, const char sep);

#endif