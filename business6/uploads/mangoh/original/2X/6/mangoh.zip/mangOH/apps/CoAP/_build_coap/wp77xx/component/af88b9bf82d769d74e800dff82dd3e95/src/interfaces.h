/*
 * AUTO-GENERATED interface.h for the coapComponent component.

 * Don't bother hand-editing this file.
 */

#ifndef __coapComponent_COMPONENT_INTERFACE_H_INCLUDE_GUARD
#define __coapComponent_COMPONENT_INTERFACE_H_INCLUDE_GUARD

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif // __coapComponent_COMPONENT_INTERFACE_H_INCLUDE_GUARD
