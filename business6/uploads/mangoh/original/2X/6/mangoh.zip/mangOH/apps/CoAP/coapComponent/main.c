#include "legato.h"

#include "./inc/client.h"

COMPONENT_INIT
{
    LE_INFO("Initialized CoAP application");
    coap_connect("192.168.50.181", "5683", COAP_PROTO_UDP);
    // coap_connect("192.168.50.181", "5684", COAP_PROTO_DTLS);

	char uri[] = "hello-world";
	char data[] = "{ \"option\": \"violence\" }";
	char query[] = "id=10&city=fafe";
	// coap_request(COAP_MESSAGE_CON, COAP_REQUEST_GET, uri, NULL, NULL);
	coap_request(COAP_MESSAGE_CON, COAP_REQUEST_POST, uri, data, query);
	coap_request(COAP_MESSAGE_CON, COAP_REQUEST_GET, uri, NULL, NULL);

    coap_connection_cleanup();
}
