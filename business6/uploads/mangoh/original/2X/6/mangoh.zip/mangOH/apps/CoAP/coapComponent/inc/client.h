#ifndef __CLIENT__H__
#define __CLIENT__H__

#include "common.h"

LE_SHARED le_result_t coap_connect(const char *const address, const char *const port, coap_proto_t proto);
LE_SHARED void coap_connection_cleanup();
LE_SHARED void coap_request(enum coap_pdu_type_t type, enum coap_pdu_code_t method, const char *path, const char *data, char *query);

#endif