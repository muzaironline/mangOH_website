# mangOH

Base project containing apps and drivers for the mangOH hardware

# Setup Legato

[Legato Get Started](https://docs.legato.io/latest/getStarted.html)

Debian dependencies packages
`build-essential python python-jinja2 python-pkg-resources python-git cmake git libsdl-dev diffstat texinfo gawk chrpath wget cpio bash ninja-build bc unzip libxml2-utils gcovr libcurl4-gnutls-dev zlib1g-dev libbz2-dev bsdiff libssl-dev autoconf automake iputils-ping libtool flex bison gperf libncursesw5-dev libncurses5-dev`

## Install Leaf

[Legato Leaf Detailed Instructions](https://docs.legato.io/latest/confLeaf.html)

### Debian base distros

`wget https://downloads.sierrawireless.com/tools/leaf/leaf_latest.deb -O /tmp/leaf_latest.deb`

`sudo apt install /tmp/leaf_latest.deb`

### Non Debian base distros

`wget https://downloads.sierrawireless.com/tools/leaf/leaf.tar.gz -O /tmp/leaf.tar.gz`

`mkdir /tmp/leaf-src && cd /tmp/leaf-src && tar xvzf /tmp/leaf.tar.gz`

#### Prerequisites:

 * `python3 python3-requests python3-argcomplete python3-all python3-setuptools`
 Note: Not all distributions have this packages but I had success with just `python3 python3-setuptools`

 * `cd /tmp/leaf-src/<folder-from-leaf.tar.gz>`
 * `./setup.py install --user`
 * `./setup.py install_data -d $HOME/.local`
 * `export PATH=$HOME/.local/bin:$PATH`

If you don't have the apt package manager `leaf env user --set LEAF_IGNORE_APT=1`

## VScode Plugin

[Plugin docs](https://docs.legato.io/latest/tools_vsCodeInstall.html)

1. Search for “Legato” in the VSCode Marketplace
1. Open a folder as your Legato workspace. Ctrl + K + 0

# Configure mangOH

[mangOH Documentation](https://mangoh.io/mangoh-yellow-resources-getting-started)

Add the mangOH Git remote, which enables Leaf to search for mangOH targets.

`leaf remote add mangOH https://downloads.sierrawireless.com/mangOH/leaf/mangOH-yellow.json --insecure`

Create a workspace

`mkdir workspace; cd workspace`

Search the Leaf remotes for packages with "mangOH" tag

`leaf search -t mangOH`

Set up the current directory as a Leaf Workspace and automatically create a profile for the target package

`leaf setup -p mangOH-yellow-wp77xx` If at any point this command fails, maybe you don't all the dependencies, if the system is not debian the leaf tool cannot verify the dependencies or it could be the GCC version witch should be version 9.3 or lower, I tested with 10 and it did not work. The error comes from mangOH not leaf.

**NOTE:** I only add success on debian 11 (blulseye) with gcc 9 the default is 10

# Clone Repo

This has to be cloned inside the `workspace` directory specified above as mangOH

`git clone --recursive git@github.com:EmituCom/Mangoh-Client.git mangOH`

Download and unpack a copy of the Bosch BSEC library, which is used by the environmental sensor app (included in the mangOH source code):

 * `cd mangOH/components/boschBsec`
 * `wget https://community.bosch-sensortec.com/varuj77995/attachments/varuj77995/bst_community-mems-forum/44/1/BSEC_1.4.7.2_GCC_CortexA7_20190225.zip`
 * `unzip BSEC_1.4.7.2_GCC_CortexA7_20190225.zip`

Enter the Leaf shell to load the development environment with the most recently used profile (in this case, the profile that was just created in this procedure). The shell now knows where the development environment components (e.g. Legato, toolchains, etc.) are located.

`leaf shell`

Then cd into the mangOH directory and build the mangOH yellow package

 * `cd $LEAF_WORKSPACE/mangOH`

**NOTE**: Make sure to edit `components/libcoapComponent/libcoap/includes/coap3/coap_debug.h` has the enum `coap_log_t` causes problems with legato, so edit it to `COAP_LOG_EMERG` instead of `LOG_EMERG`, this is for all entries in the enum.
**NOTE**: in `components/libcoapComponent/libcoap` execute the following commands `git submodule init` and `git submodule update --recursive` to get tinydstl

 * `OCTAVE=0 make yellow`
 * `update $LEAF_WORKSPACE/mangOH/build/update_files/yellow.wp77xx.update 192.168.2.2`

# Setting up a internet connection

1. `wifi client start`
1. `wifi client scan`
1. `wifi client setsecurityproto <ref> 3` // for wpa2 se other opetions in `wifi client help`
1. `wifi client setpassphrase <ref> <secrett>`
1. `wifi client connect <ref>`
1. `/sbin/udhcpc -R -b -i wlan0`
