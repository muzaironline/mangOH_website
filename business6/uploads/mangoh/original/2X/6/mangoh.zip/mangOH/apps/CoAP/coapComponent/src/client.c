#include "../inc/client.h"

coap_context_t *ctx = NULL;
coap_session_t *session = NULL;

coap_response_t response_handler(coap_session_t *session,
								 const coap_pdu_t *sent,
								 const coap_pdu_t *received,
								 const coap_mid_t mid);

/**
 * @brief Connect to a coap server
 * TODO: dtls
 *
 * @param address of the coap server
 * @param port of the coap server
 * @param proto the protocol to comunicate with the coap server
 * @return LE_OK if can resolve the address and create a session
 * @return LE_FAULT if it fails at any point
 */
le_result_t coap_connect(const char *const address, const char *const port, coap_proto_t proto)
{
	coap_address_t dst;
	coap_startup();

	if (resolve_address(address, port, &dst) < 0)
	{
		LE_CRIT("Failed to resolve address");
		goto finish;
	}

	ctx = coap_new_context(NULL);
	if (!ctx || !(session = coap_new_client_session(ctx, NULL, &dst, proto)))
	{
		LE_EMERG("Cannot create client session");
		goto finish;
	}

	coap_register_response_handler(ctx, response_handler);

	return LE_OK;

finish:
	coap_connection_cleanup();
	return LE_FAULT;
}

/**
 * @brief Clean up session and contex from connection
 */
void coap_connection_cleanup()
{
	coap_session_release(session);
	coap_free_context(ctx);
	coap_cleanup();
}

/**
 * @brief make a request GET, POST, etc.. to the server connected to
 * TODO: still missing query parameters
 *
 * @param type COAP_MESSAGE_CON,  0 confirmable message (requires ACK/RST);
 * 			   COAP_MESSAGE_NON,  1 non-confirmable message (one-shot message);
 * 			   COAP_MESSAGE_ACK,  2 used to acknowledge confirmable messages;
 *             COAP_MESSAGE_RST   3 indicates error in received messages;
 * @param method COAP_REQUEST_GET; COAP_REQUEST_POST; COAP_REQUEST_PUT; COAP_REQUEST_DELETE;
 * 				 COAP_REQUEST_FETCH; COAP_REQUEST_PATCH; COAP_REQUEST_IPATCH;
 * @param path the path to make the request to ex.: temperature making coap[server]:[port]/temperature
 * @param data the data to add to request
 * @param query the query parameters for the request
 */
void coap_request(enum coap_pdu_type_t type, enum coap_pdu_code_t method, const char *path, const char *data, char *query)
{
	coap_pdu_t *pdu = NULL;
	pdu = coap_pdu_init(type, method, coap_new_message_id(session), coap_session_max_pdu_size(session));
	if (!pdu)
	{
		LE_EMERG("Cannot create PDU");
		return;
	}

	/* add a Uri-Path option */
	if (path)
		coap_add_option(pdu, COAP_OPTION_URI_PATH, strlen(path), (const uint8_t *)path);

	if (data)
		coap_add_data(pdu, strlen(data), (const uint8_t *)data);

	if (query) 
	{
		char **tokens = str_split(query, '&');
		int i;
		for (i = 0; *(tokens + i); i++)
		{
			char *q = *(tokens + i);
			coap_add_option(pdu, COAP_OPTION_URI_QUERY, strlen(q), (const uint8_t *)q);
			free(q);
		}
	}

	coap_show_pdu(COAP_LOG_WARNING, pdu);
	coap_send(session, pdu);
	coap_io_process(ctx, COAP_IO_WAIT);
}

coap_response_t response_handler(coap_session_t *session, const coap_pdu_t *sent,
								 const coap_pdu_t *received, const coap_mid_t mid)
{
	if (!received)
		goto finish;

	coap_pdu_code_t res = coap_pdu_get_code(received);
	if (res != COAP_RESPONSE_CODE_CHANGED)
		coap_show_pdu(COAP_LOG_WARNING, received);

finish:
	return COAP_RESPONSE_OK;
}
