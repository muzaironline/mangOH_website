/**
 * @file ntag_main.c
 *
 * NTAG Command line.
 *
 * Note that since the command is run in new context each time,
 * nothing can be saved between runs.
 *
 * Copyright (C) Sierra Wireless Inc.
 */
#include "legato.h"
#include "interfaces.h"
#include "ntagDefs.h"

/* SWI mangOH Yellow has the 2K Ntag */
static Ntag ntag(Ntag::NTAG_I2C_2K, 2, 5);
static NtagEepromAdapter ntagAdapter(&ntag);

/**
 * General help message
 */
static void Usage(void)
{
    printf("ntag command line usage\n"
           "ntag help\n"
           "To run ntag command do:\n"
           "ntag COMMAND\n"
           "\terase - erase the tag - leaves an empty NDEF record\n"
           "\tclean - reset a tag back to factory-like state\n"
           "\ttext - write a text message NDEF record to the tag - rest of command-line in quotes\n"
           "\twrite - write a NDEF record to the tag - hardcoded now\n"
           "\twriteAll - write 3 NDEF records to the tag - hardcoded now\n"
           "\tread - read the tag\n"
           "\treadNdef - read the NDEF records in the tag as strings\n"
           "\tformat - NOT IMPLEMENTED - use your Android phone\n"
           "\n");
}

void TextWrite(const char *text)
{
    ntagAdapter.begin();
    NdefMessage message = NdefMessage();
    message.addTextRecord(text);

    if (!ntagAdapter.write(message))
    {
        LE_INFO("NTAG Write failed of: %s", text);
        fprintf(stderr, "NTAG Write failed of: %s\n", text);
    }
}

COMPONENT_INIT
{
    // calling ntag without arguments will print the Usage
    if (le_arg_NumArgs() < 1)
    {
        Usage();
        exit(EXIT_SUCCESS);
    }
    const char *commandPtr = le_arg_GetArg(0);

    if ((0 == strcmp(commandPtr, "help")) ||
        (0 == strcmp(commandPtr, "--help")) ||
        (0 == strcmp(commandPtr, "-h")))
    {
        Usage();
        exit(EXIT_SUCCESS);
    }

    if (strcmp(commandPtr, "readNdef") == 0)
        ReadTagExtended();
    else if (strcmp(commandPtr, "clean") == 0)
        CleanTag();
    else if (strcmp(commandPtr, "writeAll") == 0)
        WriteTagMultipleRecords();
    else if (strcmp(commandPtr, "write") == 0)
        WriteTag();
    else if (strcmp(commandPtr, "read") == 0)
        ReadTag();
    else if (strcmp(commandPtr, "erase") == 0)
        EraseTag();
    else if (strcmp(commandPtr, "text") == 0)
        TextWrite(le_arg_GetArg(1));
    else
        Usage();

    exit(EXIT_SUCCESS);
}