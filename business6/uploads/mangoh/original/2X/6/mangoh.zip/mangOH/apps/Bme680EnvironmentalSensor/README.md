# BME680 Environmental Sensor

The environment variable `$BME680_I2C_BUS` needs to be defined to an interger (e.g. `6` for wp76)
which is the I2C bus that the BME680 environmental sensor is on.
