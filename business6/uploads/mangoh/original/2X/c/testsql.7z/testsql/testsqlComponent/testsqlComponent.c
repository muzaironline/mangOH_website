// Include the core framework C APIs.
#include "legato.h"

// Include your component’s API interfaces.
#include "interfaces.h"

#include "sqlite3.h"
// #include "sqlite3ext.h"

sqlite3 *db;
void Create_Table();
void insertData();
void View_Table();

void createDb()
{
int rc ;
// sqlite3 *db;
//rc = sqlite3_open("/data/Database/internal.db", &db);
//   jyi: "/data/Database/internal.db" will have SMACK problem, change it to be in /tmp
rc = sqlite3_open("/tmp/internal.db", &db);
if(!rc)
{
LE_INFO("Successfully Created ");
Create_Table();
}
else
{
LE_INFO("Error in Opening / creating DB :%s ", sqlite3_errmsg(db));
}

// if (db)
// {
// LE_INFO("InitOperations Command For Table Creation");
// sql = "create table if not exists test_sqlite(ID int Primary key, valuename text , value int)";
// int rc = sqlite3_exec(db, sql, callback, 0, &zErrMsg);
// if (!rc)
// {
// LE_INFO("Executed Command For Table Creation");
// }
// else{
// LE_INFO("Error creation : %s",sqlite3_errmsg(db));
// }
}

static int callback(void *NotUsed, int argc, char **argv, char **azColName)
{
int i;
for(i = 0; i<argc; i++)
{
printf("%s = %s\n", azColName[i], argv[i] ? argv[i] : "NULL");
}
printf("\n");
return 0;
}

void Create_Table()
{

char *sql;
char *zErrMsg = 0;
// createDb();
if(db)
{
LE_INFO(" InitOperations Command For Table Creation ");
// sql = " table if not exists test_sqlite(ID int Primary\ key, valuename text , value int)";

sql = "CREATE TABLE if not exists Company("
"ID INT PRIMARY KEY NOT NULL,"
"NAME TEXT NOT NULL,"
"AGE INT NOT NULL,"
"ADDRESS CHAR(50),"
"SALARY REAL );";

int rc = sqlite3_exec(db, sql, callback, 0, &zErrMsg);
if(!rc)
{
LE_INFO( "Executed Command For Table Creation ");
insertData();
}
}
}

void insertData()
{
     int rc;
		if (!db)
		return;
		LE_INFO("Insert Command");
		  char *zErrMsg = 0 ;
		char *sql;
     // sqlite3_stmt *stmt;

   sql = "INSERT INTO Company (ID,NAME,AGE,ADDRESS,SALARY)\
     VALUES (5, 'XXXX', 30, 'India', 30000.00);"\
     "INSERT INTO Company (ID,NAME,AGE,ADDRESS,SALARY)\
     VALUES (6, 'YYYY', 34, 'India', 30000.00);"
     "INSERT INTO Company (ID,NAME,AGE,ADDRESS,SALARY)\
     VALUES (7, 'ZZZZ', 32, 'India', 30000.00);"   ;
/* Execute SQL statement */
rc = sqlite3_exec(db, sql, callback, 0, &zErrMsg);

LE_INFO("!!!rc value : %d",rc);

if(rc == SQLITE_OK)
{
LE_INFO( "Record created successfully");
View_Table();
}

}
void View_Table()
{
char *zErrMsg = 0;
int rc;
char *sql;
 char *data = "Callback function called";

 /* Create SQL statement */
sql = "SELECT * from Company";

// Execute SQL statement /
rc = sqlite3_exec(db, sql, callback, data, &zErrMsg);

if(rc == SQLITE_OK)
{
LE_INFO( "!!! Tabled viewed Successfully");
}

}
// This function is called only once on startup. Place your initialization and event registration
// here.
COMPONENT_INIT
{
// Write in the log that this component has started.
LE_INFO("Component SQLAppComponent started.");
createDb();

}
