#include "legato.h"
#include "interfaces.h"

static le_timer_Ref_t timerRef;

void printer_Print(const char* message)
{
    LE_INFO("******** Client says '%s'", message);
}

void timerPeriodic_test(le_timer_Ref_t timerRef)
 {
	 //LE_INFO("hi");
 }

COMPONENT_INIT
{
	le_clk_Time_t repeatInterval;
	repeatInterval.sec = 0;
	repeatInterval.usec = 100;

   timerRef = le_timer_Create ("myTimer");
	le_timer_SetHandler ( timerRef, timerPeriodic_test);
	le_timer_SetInterval( timerRef, repeatInterval);
	le_timer_SetRepeat( timerRef, 0 )	;	// 0 is forever
	le_timer_Start( timerRef );
}
