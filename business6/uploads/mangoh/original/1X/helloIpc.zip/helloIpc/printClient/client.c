#include "legato.h"
#include "interfaces.h"

static le_timer_Ref_t timerRef1;

void timerPeriodic_test(le_timer_Ref_t timerRef)
 {
	 printer_Print("This is my data");
	 //LE_INFO("inside Client Timer");
 }

COMPONENT_INIT
{
   LE_INFO("Asking server to print 'Hello, world!'");
    
   le_clk_Time_t repeatInterval;
	repeatInterval.sec = 3;
	repeatInterval.usec = 0;

   timerRef1 = le_timer_Create ("myTimer1");
	le_timer_SetHandler ( timerRef1, timerPeriodic_test);
	le_timer_SetInterval( timerRef1, repeatInterval);
	le_timer_SetRepeat( timerRef1, 0 )	;	// 0 is forever
	le_timer_Start( timerRef1 );
	
   
}
