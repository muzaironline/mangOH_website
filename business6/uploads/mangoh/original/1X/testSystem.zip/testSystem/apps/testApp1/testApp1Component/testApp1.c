#include "legato.h"
#include "interfaces.h"

COMPONENT_INIT {
  LE_INFO("Test App 1 Init");
}
