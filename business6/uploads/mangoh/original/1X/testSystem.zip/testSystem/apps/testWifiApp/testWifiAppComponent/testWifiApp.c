#include "legato.h"
#include "interfaces.h"

static void wifiClient_WiFiClientEventHandler(le_wifiClient_Event_t wifiClientEvent, void *context) {
}

COMPONENT_INIT {
  LE_INFO("Test Wifi App Init");

  // create the wifi client event handler
  le_wifiClient_NewEventHandlerRef_t wifiEventHandlerReference;
  wifiEventHandlerReference = le_wifiClient_AddNewEventHandler(
    wifiClient_WiFiClientEventHandler,
    NULL
  );
  le_wifiClient_RemoveNewEventHandler(wifiEventHandlerReference);
}
