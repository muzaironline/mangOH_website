import operator

from leaf.api import LoggerManager
from leaf.cli.base import LeafCommand
from leaf.cli.cliutils import init_common_args
from leaf.cli.meta import LeafMetaCommand
from leaf.cli.plugins import LeafPluginCommand
from leaf.core.error import LeafException
from leaf.model.base import Scope
from leaf.model.environment import Environment
from leaf.rendering.alignment import HAlign
from leaf.rendering.renderer.renderer import Renderer
from leaf.rendering.table import Table


class Feature:
    def __init__(self, name, key, description, values):
        self.name = name
        self.key = key
        self.description = description
        self.values = values

    def __str__(self):
        return "{name}={values}".format(name=self.name, values="|".join(sorted(self.values.keys())))


FEATURES = (
    Feature("legato-src", "LEGATO_SRC", "Binary or source mode for Legato framework", {"binary": None, "source": "tag", "source-master": "master"}),
    Feature("swi-linux-src", "SWI_LINUX_SRC", "Binary or source mode for Linux distribution", {"binary": None, "source": "tag", "source-master": "master"}),
)


class FeatureListRenderer(Renderer):
    def __init__(self):
        Renderer.__init__(self)

    def _tostring_default(self):
        count = 7
        table = Table(self.tm)

        # Header
        self._add_header_rows(table, count)
        if len(self) > 0:
            table.new_row().new_separator().new_cell(self.tm.LABEL("Feature"), HAlign.CENTER).new_separator().new_cell(
                self.tm.LABEL("Description"), HAlign.CENTER
            ).new_separator().new_cell(self.tm.LABEL("Values"), HAlign.CENTER).new_separator()
            table.new_row().new_double_separator(count)

            # Body
            for element in self:
                # Draw table
                table.new_row().new_separator().new_cell(element.name).new_separator().new_cell(element.description or "").new_separator().new_cell(
                    "|".join(sorted(element.values.keys()))
                ).new_separator()

            # Footer
            table.new_row().new_separator(count)

        return table

    def _tostring_verbose(self):
        count = 6
        table = Table(self.tm)

        # Header
        self._add_header_rows(table, count)

        if len(self) > 0:
            table.new_row().new_separator().new_cell(self.tm.LABEL("Feature"), HAlign.CENTER).new_separator().new_cell(
                self.tm.LABEL("Properties"), HAlign.CENTER
            ).new_hspan().new_separator()
            table.new_row().new_double_separator(count)

            # Body
            for element in self:
                labels, values = self._create_property_table(element)

                # Create table row
                table.new_row().new_separator().new_cell(element.name).new_separator().new_cell("\n".join(map(str, labels)), HAlign.RIGHT).new_cell(
                    "\n".join(map(str, values))
                ).new_separator()

                # Footer for each manifest
                table.new_row().new_separator(count)

        return table

    def _create_property_table(self, element):
        labels = []
        values = []

        # Description
        if element.description is not None:
            labels.append("Description:")
            values.append(element.description)

        # Key
        if element.key is not None:
            labels.append("Key:")
            values.append(element.key)

        # Values
        tag_count = len(element.values.items())
        if tag_count > 0:
            labels.append("Values:" if tag_count > 1 else "Value:")
            values.extend(["{enum}({value})".format(enum=k, value=v or "") for k, v in sorted(element.values.items(), key=operator.itemgetter(0))])

        return map(self.tm.LABEL, labels), values

    def _add_header_rows(self, table, size):
        count = len(self)
        title = "{count} {labeltheme}{featurelabel}{resettheme}".format(
            count=count, labeltheme=self.tm.LABEL, featurelabel="feature" if count <= 1 else "features", resettheme=self.tm.RESET
        )
        table.new_header(title, size)


class LegacyFeaturePlugin(LeafPluginCommand, LeafMetaCommand):
    def __init__(self, *args, **kwargs):
        LeafMetaCommand.__init__(self, "feature", "", [FeatureListCommand(), FeatureQueryCommand(), FeatureToggleCommand()], accept_default=True)
        LeafPluginCommand.__init__(self, *args, **kwargs)

    def execute(self, args, uargs):
        pass


class FeatureCommand(LeafCommand):
    def __init__(self, name: str, description: str):
        super().__init__(name, description)
        self.__lm = None

    @property
    def lm(self):
        if self.__lm is None:
            self.__lm = LoggerManager()
        return self.__lm

    def print_legacy_hint(self, cfgcmd: str):
        if not self.lm.logger.isquiet():
            self.lm.print_hints(
                "Command 'leaf feature {ftrcmd}' is deprecated".format(ftrcmd=self.name), "You should use 'leaf config {cfgcmd}' instead".format(cfgcmd=cfgcmd)
            )


class FeatureListCommand(FeatureCommand):
    def __init__(self):
        super().__init__("list", "list all available features")

    def execute(self, args, uargs):
        self.print_legacy_hint("list")
        renderer = FeatureListRenderer()
        for f in FEATURES:
            renderer.append(f)
        self.lm.print_renderer(renderer)


class FeatureQueryCommand(FeatureCommand):
    def __init__(self):
        super().__init__("query", "query feature status")

    def _configure_parser(self, parser):
        super()._configure_parser(parser)
        parser.add_argument("feature_name", metavar="FEATURE", nargs=1, help="the feature name")

    @staticmethod
    def find_feature(args):
        for f in FEATURES:
            if f.name == args.feature_name[0]:
                return f
        raise LeafException("Cannot find feature {name}".format(name=args.feature_name[0]), hints="use 'leaf feature list' to list all features")

    def execute(self, args, uargs):
        self.print_legacy_hint("get")
        wm = self.get_workspacemanager(check_initialized=False)

        feature = FeatureQueryCommand.find_feature(args)
        wm.logger.print_verbose("Found feature {feature.name} with key {feature.key}".format(feature=feature))

        env = Environment.build(wm.build_builtin_environment(), wm.build_user_environment())
        if wm.is_initialized:
            env.append(wm.build_ws_environment())
            env.append(wm.get_current_profile().build_environment())

        value = env.find_value(feature.key)
        wm.logger.print_verbose("Found {feature.key}={value} in env".format(feature=feature, value=value))
        value_enum = None
        for k, v in feature.values.items():
            if v == value:
                if value_enum is None:
                    value_enum = k
                else:
                    value_enum += " | " + k
        if wm.logger.isquiet():
            wm.logger.print_quiet(value_enum)
        else:
            wm.logger.print_default("{feature.name} = {values}".format(feature=feature, values=value_enum))


class FeatureToggleCommand(FeatureCommand):
    def __init__(self):
        super().__init__("toggle", "toggle a feature")

    def _configure_parser(self, parser):
        super()._configure_parser(parser)
        init_common_args(parser, with_scope=True)
        parser.add_argument("feature_name", metavar="FEATURE", nargs=1, help="the feature name")
        parser.add_argument("feature_value", metavar="VALUE", nargs=1, help="the feature value")

    def execute(self, args, uargs):
        self.print_legacy_hint("set")
        wm = self.get_workspacemanager(check_initialized=False)

        feature = FeatureQueryCommand.find_feature(args)
        wm.logger.print_verbose("Found feature {feature.name} with key {feature.key}".format(feature=feature))

        enum_value = args.feature_value[0]
        if enum_value not in feature.values:
            raise LeafException("Invalid value {value} for feature {feature.name}".format(feature=feature, value=enum_value))
        text_value = feature.values[enum_value]
        if args.env_scope == Scope.USER:
            with wm.open_user_configuration() as config:
                if text_value is None:
                    config.update_environment(unset_list=[feature.key])
                else:
                    config.update_environment(set_map={feature.key: text_value})
        elif args.env_scope == Scope.WORKSPACE:
            with wm.open_ws_configuration() as config:
                if text_value is None:
                    config.update_environment(unset_list=[feature.key])
                else:
                    config.update_environment(set_map={feature.key: text_value})
        elif args.env_scope == Scope.PROFILE or args.env_scope is None:
            profile = wm.get_current_profile()
            if text_value is None:
                profile.update_environment(unset_list=[feature.key])
            else:
                profile.update_environment(set_map={feature.key: text_value})
            wm.update_profile(profile)
