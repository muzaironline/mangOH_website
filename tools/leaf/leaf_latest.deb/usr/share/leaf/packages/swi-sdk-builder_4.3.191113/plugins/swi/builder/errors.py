"""
Legato SDK Builder

@author:    Legato Tooling Team <letools@sierrawireless.com>
@copyright: Sierra Wireless. All rights reserved.
@contact:   Legato Tooling Team <letools@sierrawireless.com>
@license:   https://www.mozilla.org/en-US/MPL/2.0/
"""
from leaf.core.error import LeafException


class EnvNotFoundException(LeafException):
    def __init__(self, name):
        LeafException.__init__(
            self, "Expected env variable '{0}' can't be found".format(name), hints="check if your profile is correctly configured with 'leaf status -v'"
        )


class NotBuildableModuleException(LeafException):
    def __init__(self, builder):
        hints = []
        if builder.is_source_supported():
            hints += ["try to enable source mode with 'leaf getsrc {0}'".format(builder.name)]
        hints += [
            ("or " if len(hints) > 0 else "")
            + "configure custom build location with 'leaf env workspace --set {0}=/path/to/location'".format(builder.custom_build_setting.key)
        ]
        LeafException.__init__(self, "Don't know how to build {0}".format(builder.name), hints=hints)


class LicenseInfoException(LeafException):
    def __init__(self):
        LeafException.__init__(
            self,
            "Missing license information",
            hints=[
                "either specify license package name with '--license NAME' option",
                "or use '--no-license' option to build packages without license (NOT RECOMMENDED)",
            ],
        )


class UnknownLicenseException(LeafException):
    def __init__(self, license_pname):
        LeafException.__init__(
            self, "Can't find required license package: " + license_pname, hints=["try to find expected license package using 'leaf search -a'"]
        )


class UnknownBuildTaskException(LeafException):
    def __init__(self, task, module):
        LeafException.__init__(self, "Unknown specified build task: " + task, hints=["see 'leaf build {0} -h' for supported tasks list".format(module)])
