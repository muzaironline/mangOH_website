#!/bin/bash
set -e
if test -n "$LEAF_DEBUG"; then set -x; fi

# Use common library
source "$LEAF_BUILD_SCRIPTS/linux/linux-common.sh"

# ----------------------------------
# Build leaf package for linux image
# ----------------------------------

# Check for image
envSetHint="or set 'SWI_LINUX_IMAGE' env var"
if test -z "$SWI_LINUX_IMAGE"; then
    testImageDeployDir

    # Computing image name
    case $module in
        ar758x|ar759x)  IMAGE_NAME_APPBOOT_RW=appsboot_rw_${module}.cwe
                        IMAGE_NAME_APPBOOT_RO=appsboot_${module}.cwe
                        IMAGE_NAME=yocto_${module}.4k.cwe
                        if test "$module" = "ar758x"; then
                            IMAGE_NAME_APPBOOT_RW_IMA=appsboot_rw_ima_${module}.cwe
                        fi;;
        wp76xx|wp77xx) IMAGE_NAME_APPBOOT_RW=appsboot_${module}.cwe
                       IMAGE_NAME=yocto_${module}.4k.cwe ;;
        wp85|wp750x) IMAGE_NAME=boot-yocto_wp85.cwe ;;
        em919x) IMAGE_NAME=boot-yocto-sdx55.img ;;
    esac

    SWI_LINUX_IMAGE=$SWI_LINUX_YOCTO_IMAGE/$IMAGE_NAME
    for imageToTest in $IMAGE_NAME $IMAGE_NAME_APPBOOT_RW $IMAGE_NAME_APPBOOT_RW_IMA $IMAGE_NAME_APPBOOT_RO; do
        # Just warn about missing pieces
        if test ! -f "$SWI_LINUX_YOCTO_IMAGE/$imageToTest"; then
            echo "Warning: expected image not found --> $SWI_LINUX_YOCTO_IMAGE/$imageToTest"
        fi
    done
fi
testFile "$SWI_LINUX_IMAGE" \
         "Can't find expected Linux image: $SWI_LINUX_IMAGE" \
         --hint "$LINUX_BUILD_HINT" \
         --hint "$IMAGE_BUILD_HINT" \
         --hint "$envSetHint"

# Reference file for package date will be the image
leafPackReferenceDateFile="${SWI_LINUX_IMAGE}"

# Compute version
leafPackVersion="${SWI_LINUX_IMAGE_PACKAGE_VERSION}"

# Setup manifest
SWI_LINUX_IMAGE_DESCRIPTION="${SWI_LINUX_IMAGE_DESCRIPTION:-Linux Image for ${moduleUpperShortName}}"
leafPackName="${moduleShortName}-linux-image"
leafPackDescription="${SWI_LINUX_IMAGE_DESCRIPTION}"
leafManifestExtraArgs=""
leafManifestTemplate="$LEAF_BUILD_SCRIPTS/templates/linux-image.json"
leafBuildManifest

# Ready to copy
bundleFile "$SWI_LINUX_IMAGE" "linux.cwe"
if test -n "$IMAGE_NAME_APPBOOT_RW" -a -f "$SWI_LINUX_YOCTO_IMAGE/$IMAGE_NAME_APPBOOT_RW"; then
    bundleFile "$SWI_LINUX_YOCTO_IMAGE/$IMAGE_NAME_APPBOOT_RW"
fi
if test -n "$IMAGE_NAME_APPBOOT_RW_IMA" -a -f "$SWI_LINUX_YOCTO_IMAGE/$IMAGE_NAME_APPBOOT_RW_IMA"; then
    bundleFile "$SWI_LINUX_YOCTO_IMAGE/$IMAGE_NAME_APPBOOT_RW_IMA"
fi
if test -n "$IMAGE_NAME_APPBOOT_RO" -a -f "$SWI_LINUX_YOCTO_IMAGE/$IMAGE_NAME_APPBOOT_RO"; then
    bundleFile "$SWI_LINUX_YOCTO_IMAGE/$IMAGE_NAME_APPBOOT_RO"
fi

# Ready to build package
leafBuildPackage -j
