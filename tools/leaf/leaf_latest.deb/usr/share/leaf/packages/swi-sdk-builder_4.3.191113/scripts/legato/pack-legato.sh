#!/bin/bash
set -e
if test -n "$LEAF_DEBUG"; then set -x; fi

# Use common library
source "$LEAF_BUILD_SCRIPTS/legato/legato-common.sh"

# ---------------------------------
# Build leaf package for legato fwk
# ---------------------------------

# Compute version
leafPackVersion="${LEGATO_PACKAGE_VERSION}"

# Reference file for package date will be the Legato image
leafPackReferenceDateFile="${LEGATO_BUILT_IMAGE}"

# Check bin directory
LEGATO_BIN_DIR="${LEGATO_ROOT}/bin"
testDir "${LEGATO_BIN_DIR}" \
        "Can't find Legato tools dir: ${LEGATO_BIN_DIR}" \
        --hint "$LEGATO_BUILD_HINT"

# Check if the package provides a Language Server
# TODO: restore this if we want Legato package to export Language Server again later
#legatoLanguageServerOffset="bin/languageServer/languageServer.js"
#if test -f "${LEGATO_ROOT}/$legatoLanguageServerOffset"; then
#    export legatoLanguageServerOffset
#    leafManifestExtraArgs="$leafManifestExtraArgs --append $LEAF_BUILD_SCRIPTS/templates/legato-lang-server.json"
#fi

# Look for Legato archive
LEGATO_ARCHIVE=${LEGATO_ARCHIVE:-${LEGATO_RELEASE_DIR}/legato.tar.bz2}
testFile "${LEGATO_ARCHIVE}" \
         "Legato archive file is not found: ${LEGATO_ARCHIVE}" \
         --hint "$LEGATO_RELEASE_HINT"

# Extract Legato archive in staging dir
tar xjf "${LEGATO_ARCHIVE}" -C "${LEGATO_STAGING_DIR}"
LEGATO_ARCHIVE_DIR="$(find "${LEGATO_STAGING_DIR}" -maxdepth 1 -mindepth 1 -type d -name "legato-*")"
mv $(find "${LEGATO_ARCHIVE_DIR}/" -maxdepth 1 -mindepth 1) "${LEGATO_STAGING_DIR}"
rm -R "${LEGATO_ARCHIVE_DIR}"

# Check if the package provides code snippets files
# TODO: restore this if we want Legato package to export snippets again later
#legatoCodeSnippetFiles="$(cd ${LEGATO_STAGING_DIR} && find -name "*.code-snippets" | sort)"
#if test -n "$legatoCodeSnippetFiles"; then
#    export legatoCodeSnippetsList="$(echo "$legatoCodeSnippetFiles" | sed -e "s|\./\(.*\)/.*\.code-snippets|\$LEGATO_ROOT/\1|g" | sort -u | tr '\n' ':')"
#    leafManifestExtraArgs="$leafManifestExtraArgs --append $LEAF_BUILD_SCRIPTS/templates/legato-snippets.json"
#fi

# Handle host tools (mk)
if test -e "${LEGATO_ROOT}/build/tools/mk"; then
    # Legacy mode: only mk
    leafManifestExtraArgs="$leafManifestExtraArgs --append $LEAF_BUILD_SCRIPTS/templates/legato-mk-old.json"
elif test -e "${LEGATO_ROOT}/build/tools/bin/mk" -a -e "${LEGATO_ROOT}/build/tools/lib/libdefTools.so"; then
    # Need to deal with companion lib (from 19.04)
    leafManifestExtraArgs="$leafManifestExtraArgs --append $LEAF_BUILD_SCRIPTS/templates/legato-mk-new.json"
else
    # Don't know what to do with mk
    error "Internal error: can't find mk tool"
fi

# Setup manifest
LEGATO_DESCRIPTION="${LEGATO_DESCRIPTION:-Legato Framework built for ${moduleUpperShortName}}"
leafPackName="${moduleShortName}-legato"
leafPackDescription="${LEGATO_DESCRIPTION}"
leafManifestExtraArgs="$leafManifestExtraArgs --requires swi-aptdeps-legato_latest --requires $swiVerifyDeps"
leafManifestTemplate="$LEAF_BUILD_SCRIPTS/templates/legato.json"
leafBuildManifest

# Setup build dirs
LEGATO_STAGING_BUILD_DIR="${LEGATO_STAGING_DIR}/build/${LEGATO_TARGET}"
LEGATO_STAGING_BUILD_FWK_DIR="${LEGATO_STAGING_BUILD_DIR}/framework"
LEGATO_BUILD_FWK_DIR="${LEGATO_BUILD_DIR}/framework"

# Copy built libs/bins + tools (including devMode app)
mkdir -p "${LEGATO_STAGING_BUILD_FWK_DIR}"
cp -a "${LEGATO_BUILD_FWK_DIR}/bin" "${LEGATO_BUILD_FWK_DIR}/lib" "${LEGATO_BUILD_FWK_DIR}/md5" "${LEGATO_STAGING_BUILD_FWK_DIR}"
mkdir -p "${LEGATO_STAGING_BUILD_FWK_DIR}/libjansson"
cp -a "${LEGATO_BUILD_FWK_DIR}/libjansson/include/" "${LEGATO_STAGING_BUILD_FWK_DIR}/libjansson"
cp -a "${LEGATO_BUILD_DIR}/tools" "${LEGATO_STAGING_BUILD_DIR}"

# Handle host tools (mk)
if echo "$leafManifestExtraArgs" | grep -q "legato-mk-old.json"; then
    # Legacy mode: only mk
    mkdir -p "${LEGATO_STAGING_DIR}/build/tools"
    cp -a "${LEGATO_ROOT}/build/tools/mk" "${LEGATO_STAGING_DIR}/build/tools/mk-$(uname -m)"
else
    # Need to deal with companion lib (from 19.04)
    mkdir -p "${LEGATO_STAGING_DIR}/build/tools/bin"
    cp -a "${LEGATO_ROOT}/build/tools/bin/mk" "${LEGATO_STAGING_DIR}/build/tools/bin/mk-$(uname -m)"
    mkdir -p "${LEGATO_STAGING_DIR}/build/tools/lib"
    cp -a "${LEGATO_ROOT}/build/tools/lib/libdefTools.so" "${LEGATO_STAGING_DIR}/build/tools/lib/libdefTools.so-$(uname -m)"
fi

# Copy built includes + config scripts only if present (from 18.12)
if test -d "${LEGATO_BUILD_FWK_DIR}/include"; then
    cp -a "${LEGATO_BUILD_FWK_DIR}/include" "${LEGATO_STAGING_BUILD_FWK_DIR}"
fi
if test -e "${LEGATO_BUILD_DIR}/config.sh"; then
    cp -a "${LEGATO_BUILD_DIR}"/config.* "${LEGATO_STAGING_BUILD_DIR}"
fi

# User documentation
initLegatoDocDir
cp -a -L "${LEGATO_DOC_DIR}" "${LEGATO_STAGING_DIR}"

# Rework links to make them relative if necessary
LEGATO_BIN_STAGING="${LEGATO_ROOT}/_bin"
cp -a "${LEGATO_BIN_DIR}" "${LEGATO_BIN_STAGING}"
for linkedTool in $(find "${LEGATO_BIN_STAGING}" -type l); do
    linkTarget="$(readlink -f $linkedTool || true)"
    linkOption="-nfsr"
    if test -z "$linkTarget"; then
        # Link may not exist now, so guess it from inexisting path
        linkTarget="$(readlink $linkedTool | sed -e "s|.*/legato/\(.*\)|../\1|")"
        linkOption="-fs"
    fi
    if test "$(basename $linkedTool)" = "mk" -o "$(basename $linkTarget)" != "mk"; then
        rm "$linkedTool"
        ln $linkOption "$linkTarget" "$linkedTool"
    fi
done
cp -a "${LEGATO_BIN_STAGING}" "${LEGATO_STAGING_DIR}/bin"
rm -Rf "${LEGATO_BIN_STAGING}"

# Ready to build package
leafBuildPackage -J
