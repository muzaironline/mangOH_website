#!/bin/bash
set -e
if test -n "$LEAF_DEBUG"; then set -x; fi

# Use common library
source "$LEAF_BUILD_SCRIPTS/sdk/sdk-common.sh"

# -----------------------------------
# Build leaf package for device image
# -----------------------------------

CHECK_INSTALLED_PACK_HINT="please check generated/installed packages"

# Setup versions
modemImgVersion="$(extractVersion $LEAF_BUILD_SDK_DEP_MODEM_IMG)"

# Handle signed modem image
__handleSignedModem

# Function to list package content
grepPackageFiles() {
    local packageID=${1%%(*}
    local filePattern=$2

    # Look if package is coming from current profile deps, or is a custom built one
    local packageDir=$LEAF_WORKSPACE/leaf-data/current/${packageID%%_*}
    local packageArchive=$LEAF_BUILD_OUTPUT/${packageID}.leaf
    if test -e "$packageDir" -a "$(basename $(readlink -f $packageDir))" = "$packageID"; then
        # Simply list package content
        local packageFiles=$(cd $packageDir && ls -1d ./*)
    elif test -f "$packageArchive"; then
        # Dump archive content
        local packageFiles=$(tar tjf $packageArchive)
    else
        # Well, we have a problem
        error "Can't find image package content (looked in $packageDir and $packageArchive)" \
              --hint "$CHECK_INSTALLED_PACK_HINT"
    fi

    echo "$packageFiles" | grep $filePattern | sed -e "s|\./||g" || true
}

# List modem images
modemImages="$(grepPackageFiles ${LEAF_BUILD_SDK_DEP_MODEM_IMG} .spk)"
mcuImage=$(grepPackageFiles ${LEAF_BUILD_SDK_DEP_MODEM_IMG} mcu)
if test -n "$mcuImage"; then
    inputMcuImage="modem/$mcuImage"
fi
bootImages="$(grepPackageFiles ${LEAF_BUILD_SDK_DEP_MODEM_IMG} boot.*cwe)"
if test -z "$bootImages"; then
    bootImages="@@fakeboot@@"
fi
linuxBootImages="$(grepPackageFiles ${LEAF_BUILD_SDK_DEP_LINUX_IMG} appsboot.*cwe)"

# Build concatenation command
if test -n "$modemImages"; then
    for modemImage in $modemImages; do
        for bootImage in $bootImages; do
            imageSuffix=""
            legatoImageName=legato.cwe
            inputBootImage=""
            inputLinuxBootImage=""
            if test "$bootImage" = "boot_rw.cwe"; then
                imageSuffix="-rw"
                legatoImageName=legato_rw.cwe
                inputBootImage=modem/$bootImage
                linuxBootImageCandidate=appsboot_rw_${module}.cwe
                if echo "$linuxBootImages" | grep "$linuxBootImageCandidate"; then
                    # The image is really provided in the Linux package, use it
                    linuxBootImage=$linuxBootImageCandidate
                    inputLinuxBootImage=linux/$linuxBootImage
                fi
            elif test "$bootImage" = "boot.cwe"; then
                if test "$bootImage" = "$bootImages"; then
                    # Only one boot image: no need to tag with "rw/ro"
                    inputBootImage=modem/$bootImage
                else
                    # Several boot images: this one will be the "ro" one
                    imageSuffix="-ro"
                    legatoImageName=legato_ro.cwe
                    inputBootImage=modem/$bootImage
                    linuxBootImageCandidate=appsboot_${module}.cwe
                    if echo "$linuxBootImages" | grep "$linuxBootImageCandidate"; then
                        # The image is really provided in the Linux package, use it
                        linuxBootImage=$linuxBootImageCandidate
                        inputLinuxBootImage=linux/$linuxBootImage
                    fi
                fi
            elif test "$bootImage" != "@@fakeboot@@"; then
                echo "Unknown boot image: $bootImage"
                exit 1
            else
                # No RO/RW management; but maybe a linux appsboot?
                if test -n "$linuxBootImages"; then
                    # Assuming there is only one
                    linuxBootImage=$linuxBootImages
                    inputLinuxBootImage=linux/$linuxBootImage
                fi
            fi

            # Verify image names
            legatoTry="$(grepPackageFiles ${LEAF_BUILD_SDK_DEP_LEGATO_IMG} $legatoImageName)"
            if test -z "$legatoTry" -a "$legatoImageName" != "legato.cwe"; then
                # Maybe we only get one Legato image after all
                legatoImageName=legato.cwe
                legatoTry="$(grepPackageFiles ${LEAF_BUILD_SDK_DEP_LEGATO_IMG} $legatoImageName)"
            fi
            testString "$legatoTry" \
                       "Can't find $legatoImageName legato image in ${LEAF_BUILD_SDK_DEP_LEGATO_IMG}" \
                       --hint "$CHECK_INSTALLED_PACK_HINT"
            testString "$(grepPackageFiles ${LEAF_BUILD_SDK_DEP_LINUX_IMG} linux.cwe)" \
                       "Can't find linux image in  ${LEAF_BUILD_SDK_DEP_LINUX_IMG}" \
                       --hint "$CHECK_INSTALLED_PACK_HINT"
            if test -n "$linuxBootImage"; then
                testString "$(grepPackageFiles ${LEAF_BUILD_SDK_DEP_LINUX_IMG} $linuxBootImage)" \
                           "Can't find $linuxBootImage linux boot image in  ${LEAF_BUILD_SDK_DEP_LINUX_IMG}" \
                           --hint "$CHECK_INSTALLED_PACK_HINT"
            fi

            # Build manifest fragment
            spkFile=${modemImage%.spk}${imageSuffix}-full.spk
            inputFiles=""
            for inputFileCandidate in "$inputBootImage" "modem/$modemImage" "$inputMcuImage" "$inputLinuxBootImage" "linux/linux.cwe" "legato/${legatoImageName}"; do
                if test -n "$inputFileCandidate"; then
                    if test -n "$inputFiles"; then
                        inputFiles="${inputFiles}\",\""
                    fi
                    inputFiles="${inputFiles}${inputFileCandidate}"
                fi
            done
            generatedFragment=$(mktemp)
            cat $LEAF_BUILD_SCRIPTS/templates/image-extra.json | sed -e "s|{spkFile}|${spkFile}|g;s|{inputFiles}|${inputFiles}|g" > $generatedFragment
            leafManifestImageExtraArgs="$leafManifestImageExtraArgs --append $generatedFragment"
        done
    done
else
    error "No modem images found in ${LEAF_BUILD_SDK_DEP_MODEM_IMG} package" \
          --hint "$CHECK_INSTALLED_PACK_HINT"
fi

# Reference file for package date will be the Legato image package
LEGATO_IMG_PACKAGE="$LEAF_BUILD_OUTPUT/${LEAF_BUILD_SDK_DEP_LEGATO_IMG%(*}.leaf"
testFile "$LEGATO_IMG_PACKAGE" \
         "Can't find custom Legato package to setup Image timestamp: $LEGATO_IMG_PACKAGE"
leafPackReferenceDateFile="$LEGATO_IMG_PACKAGE"

# Rework deps to remove conditions
modemImgID=${LEAF_BUILD_SDK_DEP_MODEM_IMG%%(*}
legatoImgID=${LEAF_BUILD_SDK_DEP_LEGATO_IMG%%(*}
linuxImgID=${LEAF_BUILD_SDK_DEP_LINUX_IMG%%(*}

# Setup manifest
LEAF_BUILD_IMAGE_DESCRIPTION="${LEAF_BUILD_IMAGE_DESCRIPTION:-Device Image for ${moduleUpperShortName}${SDK_LABEL}}"
leafPackName="${moduleShortName}-image"
leafPackDescription="${LEAF_BUILD_IMAGE_DESCRIPTION}"
leafManifestTemplate="$LEAF_BUILD_SCRIPTS/templates/image.json"
leafManifestExtraArgs="$leafManifestExtraArgs \
--requires swi-aptdeps-image_latest \
--requires $swiVerifyDeps \
--depends ${modemImgID} \
--depends ${legatoImgID} \
--depends ${linuxImgID} \
${leafManifestImageExtraArgs}"
export modemImgID
export legatoImgID
export linuxImgID
leafBuildManifest

# Ready to build package
leafBuildPackage -j
