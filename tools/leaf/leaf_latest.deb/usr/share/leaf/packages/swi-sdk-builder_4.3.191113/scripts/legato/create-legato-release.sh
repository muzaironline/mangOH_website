#!/bin/bash
set -e
if test -n "$LEAF_DEBUG"; then set -x; fi

function __copyImages {
    for file in $(find build/$LEGATO_TARGET -maxdepth 1 -regextype sed -regex '.*legato.*\.\(cwe\|yaffs2\|ubi\)'); do
        IMG_FULLNAME=$(basename $file)
        IMG_NAME="${IMG_FULLNAME%.*}"
        IMG_EXT="${IMG_FULLNAME##*.}"

        DST_NAME="${IMG_NAME}-${LEGATO_TARGET}-${LEVERSION}.${IMG_EXT}"
        DST_NAME_LINK="${IMG_NAME}-${LEGATO_TARGET}.${IMG_EXT}"

        echo "Copying image as $DST_NAME"
        cp "$file" "releases/$DST_NAME"

        echo "Creating symlink as $DST_NAME_LINK"
        rm -f "releases/$DST_NAME_LINK"
        ln -s "$DST_NAME" "releases/$DST_NAME_LINK"
    done
}

cd "$LEGATO_ROOT"

if test -d .git -a -z "$(git remote -v | grep "github\.com")"; then
    # Use releaselegato script only for internal clone
    releaselegato -t "$LEGATO_TARGET"
else
    # Alternative logic to build Legato archive
    TMPDIR="$(mktemp -d)"
    rm -Rf "$TMPDIR"
    if test -d releases; then
        rm -Rf releases
    fi
    LEVERSION=$(cat version)
    mkdir -p "$TMPDIR/legato-$LEVERSION"
    cp -arf ./ "$TMPDIR/legato-$LEVERSION"
    pushd "$TMPDIR/legato-$LEVERSION"
    make clean
    rm -Rf .config $(find -name ".git")
    popd
    
    mkdir releases
    cp -arf "$TMPDIR/legato-$LEVERSION" releases

    __copyImages

    pushd releases
    tar caf "legato-${LEVERSION}.tar.bz2" "legato-$LEVERSION"
    ln -s "legato-${LEVERSION}.tar.bz2" "legato.tar.bz2"
    popd
fi
