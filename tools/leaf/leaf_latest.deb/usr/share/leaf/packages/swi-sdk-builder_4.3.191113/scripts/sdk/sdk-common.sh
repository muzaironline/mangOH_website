# Common library for SDK packages build

# Get builders common library
source ${LEAF_BUILD_SCRIPTS}/leaf-build-common.sh

# Version extraction
extractVersion() {
    local packageID=${1%%(*}
    local version=${packageID#*_}
    testString "$version" \
               "Can't read version from $1"
    echo "$version"
}

# Staging dir setup
SWI_SDK_STAGING_DIR=$(mktemp -d)
leafPackStagingDir="${SWI_SDK_STAGING_DIR}"

# Compute version
leafPackVersion="${LEAF_BUILD_SDK_VERSION}"
if test -n "${LEGATO_BUILD_VARIANT}"; then
    # Append build variant to version, if any
    leafPackVersion="${leafPackVersion}-${LEGATO_BUILD_VARIANT}"
fi

__handleSignedModem() {
    # Signed/unsigned modem image management (only for internal SDKs)
    if test "$LEAF_BUILD_REPO_TYPE" = "internal"; then
        if echo "${modemImgVersion}" | grep -q "signed"; then
            # Signed internal SDK: add tag and version
            leafManifestExtraArgs="$leafManifestExtraArgs --tag signed"
            leafPackVersion="${leafPackVersion}-signed"
        else
            # Unsigned: add only tag
            leafManifestExtraArgs="$leafManifestExtraArgs --tag unsigned"
        fi
    fi
}

# Setup label
if test -n "${LEAF_BUILD_SDK_LABEL}"; then
    SDK_LABEL=" (${LEAF_BUILD_SDK_LABEL})"
fi
