"""
Legato SDK Builder

@author:    Legato Tooling Team <letools@sierrawireless.com>
@copyright: Sierra Wireless. All rights reserved.
@contact:   Legato Tooling Team <letools@sierrawireless.com>
@license:   https://www.mozilla.org/en-US/MPL/2.0/
"""

import os
from argparse import ArgumentParser

from leaf.core.error import LeafException
from leaf.model.package import PackageIdentifier

from .builders import Builder, CleanBuildTask, IndexBuildTask, PackBuildTask
from .cmd import SettingUpdateAction
from .env import BuildSettings
from .compat import CSetting, compat_get_packages


class DepConditions:
    LEGATO_BIN = "(!LEGATO_SRC)"
    LEGATO_SRC = "(LEGATO_SRC)"
    LINUX_BIN = "(!SWI_LINUX_SRC)"
    LINUX_SRC = "(SWI_LINUX_SRC)"
    HOST64 = "(LEAF_PLATFORM_MACHINE=x86_64)"
    HOST32 = "(LEAF_PLATFORM_MACHINE=i686)"


class DepDescriptor:
    def __init__(self, name, label, var, src_condition=None, version_suffix=None):
        self.name = name
        self.label = label
        self.setting = CSetting(var)
        self.src_condition = src_condition
        self.version_suffix = version_suffix


class SdkDeps:
    LEGATO = DepDescriptor("legato", "legato", "LEAF_BUILD_SDK_DEP_LEGATO", src_condition=DepConditions.LEGATO_BIN)
    LEGATO_IMG = DepDescriptor("legato-image", "legato image", "LEAF_BUILD_SDK_DEP_LEGATO_IMG", src_condition=DepConditions.LEGATO_BIN)
    LEGATO_SRC = DepDescriptor("legato-src", "legato source", "LEAF_BUILD_SDK_DEP_LEGATO_SRC", src_condition=DepConditions.LEGATO_SRC)
    TOOLCHAIN64 = DepDescriptor(
        "toolchain",
        "toolchain 64 bits",
        "LEAF_BUILD_SDK_DEP_TOOLCHAIN64",
        src_condition=DepConditions.HOST64 + DepConditions.LINUX_BIN,
        version_suffix="-linux64",
    )
    TOOLCHAIN32 = DepDescriptor(
        "toolchain",
        "toolchain 32 bits",
        "LEAF_BUILD_SDK_DEP_TOOLCHAIN32",
        src_condition=DepConditions.HOST32 + DepConditions.LINUX_BIN,
        version_suffix="-linux32",
    )
    LINUX_IMG = DepDescriptor("linux-image", "linux image", "LEAF_BUILD_SDK_DEP_LINUX_IMG", src_condition=DepConditions.LINUX_BIN)
    LINUX_SRC = DepDescriptor("linux-src", "linux source", "LEAF_BUILD_SDK_DEP_LINUX_SRC", src_condition=DepConditions.LINUX_SRC)
    MODEM_IMG = DepDescriptor("modem-image", "modem image", "LEAF_BUILD_SDK_DEP_MODEM_IMG")
    DEVICE_IMG = DepDescriptor("image", "full image", "LEAF_BUILD_SDK_DEP_FULL_IMG", src_condition=DepConditions.LEGATO_BIN + DepConditions.LINUX_BIN)


class SdkCleanBuild(CleanBuildTask):
    def build(self):
        self.shell_call("rm -f $LEAF_BUILD_OUTPUT/${LEGATO_TARGET}-image_*.leaf*")
        self.shell_call("rm -f $LEAF_BUILD_OUTPUT/${LEAF_BUILD_SDK_PREFIX}-${LEGATO_TARGET}_*.leaf*")


class SdkPackBuild(PackBuildTask):
    def setup_custom_deps(self):
        self.custom_packs_dir = BuildSettings.OUTPUT.value
        self.custom_leaf_pis = list(map(lambda f: f[:-5], filter(lambda f: f.endswith(".leaf"), os.listdir(self.custom_packs_dir))))

    def get_custom_pi(self, dep: DepDescriptor):
        # Look for a given PI in generated custom packages
        custom_target = BuildSettings.MODULE.value
        target = custom_target if custom_target is not None else self.bm.legato_target_short
        shortlist = list(
            filter(
                lambda pi: pi.startswith(target + "-" + dep.name + "_") and (pi.endswith(dep.version_suffix) if dep.version_suffix is not None else True),
                self.custom_leaf_pis,
            )
        )
        if len(shortlist) == 0:
            return None
        if len(shortlist) > 1:
            raise LeafException(
                message="Can't determine which package to use among found built ones: " + ", ".join(shortlist),
                hints=["Please check your built {0} packages".format(dep.name)],
            )
        return shortlist[0]

    def get_initial_pi(self, dep: DepDescriptor):
        # Look for a given PI in SDK initial dependencies
        target = self.bm.legato_target_short
        prefix = target + "-" + dep.name + "_"

        # Keep packages that:
        # - match the expected dep name
        # - match the expected dep version suffix (if specified)
        shortlist = list(
            filter(lambda pi: pi.startswith(prefix) and (dep.version_suffix is None or pi.endswith(dep.version_suffix + dep.src_condition)), self.initial_deps)
        )
        if len(shortlist) == 0 or len(shortlist) > 1:
            if dep.name == "toolchain" and dep.version_suffix == "-linux32":
                dep.src_condition = "(LEAF_PLATFORM_MACHINE=i386)" + DepConditions.LINUX_BIN
                shortlist = list(
                    filter(
                        lambda pi: pi.startswith(prefix) and (dep.version_suffix is None or pi.endswith(dep.version_suffix + dep.src_condition)),
                        self.initial_deps,
                    )
                )
            if len(shortlist) == 0 or len(shortlist) > 1:
                raise LeafException(message="Internal error: can't find initial dep for " + prefix)
        return shortlist[0]

    def add_dep(self, dep: DepDescriptor, is_custom=False, value=None, use_src_condition=False):
        if not is_custom and value is None:
            value = self.get_initial_pi(dep)
        if use_src_condition and dep.src_condition is not None:
            value += dep.src_condition
        self.bm.wm.logger.print_default("  [{custom}] {label}: {value}".format(custom="custom" if is_custom else "inherited", label=dep.label, value=value))
        dep.setting.value = value

    def check_legato_deps(self):
        # Check if a custom Legato package has been generated
        custom_legato = self.get_custom_pi(SdkDeps.LEGATO)
        if custom_legato is None:
            if self.initial_deps is not None:
                # Reuse all Legato packages from original SDK
                self.add_dep(SdkDeps.LEGATO)
                self.add_dep(SdkDeps.LEGATO_IMG)
                self.add_dep(SdkDeps.LEGATO_SRC)
        else:
            # Get custom ones
            custom_legato_src = self.get_custom_pi(SdkDeps.LEGATO_SRC)
            self.use_custom_legato_src = custom_legato_src is not None
            custom_legato_image = self.get_custom_pi(SdkDeps.LEGATO_IMG)

            # Main deps
            self.add_dep(SdkDeps.LEGATO, is_custom=True, value=custom_legato, use_src_condition=self.use_custom_legato_src)
            self.add_dep(SdkDeps.LEGATO_IMG, is_custom=True, value=custom_legato_image, use_src_condition=self.use_custom_legato_src)
            if self.use_custom_legato_src:
                # Legato packages with source mode support
                self.add_dep(SdkDeps.LEGATO_SRC, is_custom=True, value=custom_legato_src, use_src_condition=self.use_custom_legato_src)

        return custom_legato is not None

    def check_toolchain_deps(self):
        # Check if custom Toolchain packages have been generated
        custom_toolchain = self.get_custom_pi(SdkDeps.TOOLCHAIN64)
        if custom_toolchain is None:
            if self.initial_deps is not None:
                # Reuse both toolchain packages from original SDK
                self.add_dep(SdkDeps.TOOLCHAIN64, is_custom=False, value=self.get_initial_pi(SdkDeps.TOOLCHAIN64))
                self.add_dep(SdkDeps.TOOLCHAIN32, is_custom=False, value=self.get_initial_pi(SdkDeps.TOOLCHAIN32))
        else:
            # Get custom one
            self.add_dep(SdkDeps.TOOLCHAIN64, is_custom=True, value=custom_toolchain, use_src_condition=self.use_custom_linux_src)

            # Optionally add 32 bits custom one if any
            custom_toolchain32 = self.get_custom_pi(SdkDeps.TOOLCHAIN32)
            if custom_toolchain32 is not None:
                self.add_dep(SdkDeps.TOOLCHAIN32, is_custom=True, value=custom_toolchain32, use_src_condition=self.use_custom_linux_src)

        return custom_toolchain is not None

    def check_linux_image_deps(self):
        # Check if a custom Linux Image package has been generated
        custom_image = self.get_custom_pi(SdkDeps.LINUX_IMG)
        if custom_image is None:
            if self.initial_deps is not None:
                # Reuse Linux image packages from original SDK
                self.add_dep(SdkDeps.LINUX_IMG)
        else:
            # Get custom one
            self.add_dep(SdkDeps.LINUX_IMG, is_custom=True, value=custom_image, use_src_condition=self.use_custom_linux_src)

        return custom_image is not None

    def check_linux_src_deps(self):
        # Check if a custom Linux Source package has been generated
        custom_linux_src = self.get_custom_pi(SdkDeps.LINUX_SRC)
        self.use_custom_linux_src = custom_linux_src is not None
        if not self.use_custom_linux_src:
            if self.initial_deps is not None:
                # Reuse Linux source packages from original SDK
                self.add_dep(SdkDeps.LINUX_SRC)
        else:
            # Get custom one
            self.add_dep(SdkDeps.LINUX_SRC, is_custom=True, value=custom_linux_src, use_src_condition=True)

        return self.use_custom_linux_src

    def check_modem_image_deps(self):
        # Check if a custom modem image package is present
        custom_modem = self.get_custom_pi(SdkDeps.MODEM_IMG)
        if custom_modem is None:
            if self.initial_deps is not None:
                # Reuse Linux image packages from original SDK
                self.add_dep(SdkDeps.MODEM_IMG)
                return True
        else:
            # Get custom one
            self.add_dep(SdkDeps.MODEM_IMG, is_custom=True, value=custom_modem)
            return True

    def build(self):
        # Determine initial SDK to reuse
        current_profile = self.bm.wm.get_profile(self.bm.wm.current_profile_name)
        packages = compat_get_packages(current_profile)
        target = self.bm.legato_target_short
        sdk_short_list = list(filter(lambda pi: pi.endswith("-" + target), packages.keys()))
        if len(sdk_short_list) > 1:
            raise LeafException(
                message="Can't determine which SDK to use among referenced packages: " + ", ".join(sdk_short_list), hints=["Please check your configuration"]
            )
        if len(sdk_short_list) == 0:
            self.used_sdk = None
            self.initial_deps = None
            self.bm.wm.logger.print_default("Can't find any SDK for {0} in current profile; will create a brand new one".format(target))
        else:
            used_sdk_pi_name = sdk_short_list[0]
            used_sdk_pi_version = packages[used_sdk_pi_name]
            used_sdk_pi = PackageIdentifier(used_sdk_pi_name, used_sdk_pi_version)
            self.bm.wm.logger.print_default("Reusing dependencies from " + str(used_sdk_pi))

            # List initial dependencies
            self.used_sdk = self.bm.wm.list_installed_packages()[used_sdk_pi]
            self.initial_deps = self.used_sdk.depends_packages

        # Populate custom dependencies
        self.setup_custom_deps()
        custom_builds_found = False
        custom_builds_found |= self.check_legato_deps()
        custom_builds_found |= self.check_linux_src_deps()
        custom_builds_found |= self.check_toolchain_deps()
        custom_builds_found |= self.check_linux_image_deps()
        is_modem_present = self.check_modem_image_deps()

        # Is there at least one custom thing?
        if not custom_builds_found:
            raise LeafException(
                message="Can't find any custom built packages", hints=["please build either Legato or Linux custom packages with 'leaf build xxx' commands"]
            )

        # Delegate leaf packages build to scripts
        if is_modem_present:
            # Build device image only if we get a modem image
            self.shell_call("$LEAF_BUILD_SCRIPTS/sdk/pack-image.sh")

            # Add dependency for device image (after custom deps refresh)
            self.setup_custom_deps()
            self.add_dep(
                SdkDeps.DEVICE_IMG,
                is_custom=True,
                value=self.get_custom_pi(SdkDeps.DEVICE_IMG),
                use_src_condition=self.use_custom_linux_src or self.use_custom_legato_src,
            )

        # Final SDK packaging
        self.shell_call("$LEAF_BUILD_SCRIPTS/sdk/pack-sdk.sh")


class SdkBuilder(Builder):
    def get_build_tasks(self):
        return [SdkCleanBuild(), SdkPackBuild(), IndexBuildTask()]

    def add_options(self, parser: ArgumentParser):
        # Need an option to specify SDK version
        parser.add_argument(
            "--version",
            metavar="VERSION",
            action=SettingUpdateAction,
            dest=BuildSettings.SDK_VERSION.key,
            nargs=1,
            help="build SDK leaf packages with specified VERSION",
        )

        # Need an option to set SDK prefix
        parser.add_argument(
            "--prefix",
            metavar="PREFIX",
            action=SettingUpdateAction,
            dest=BuildSettings.SDK_PREFIX.key,
            nargs=1,
            help="build SDK leaf package with specified PREFIX",
        )

    def check_options(self, args, enabled_tasks):
        # Check enabled tasks
        is_packing = False
        for task in enabled_tasks.values():
            if isinstance(task, PackBuildTask):
                is_packing = True
                break

        # Check args only if building packages
        if is_packing:
            # Check if version is specified
            if not BuildSettings.SDK_VERSION.is_set():
                raise LeafException(
                    message="SDK leaf packages version is not specified",
                    hints=["Please use '--version' option", "or set '{0}' env var".format(BuildSettings.SDK_VERSION.key)],
                )

            # Check if prefix is specified
            if not BuildSettings.SDK_PREFIX.is_set():
                raise LeafException(
                    message="SDK prefix is not specified", hints=["Please use '--prefix' option", "or set '{0}' env var".format(BuildSettings.SDK_PREFIX.key)]
                )
