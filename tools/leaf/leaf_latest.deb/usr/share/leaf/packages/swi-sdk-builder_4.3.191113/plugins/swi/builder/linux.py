"""
Legato SDK Builder

@author:    Legato Tooling Team <letools@sierrawireless.com>
@copyright: Sierra Wireless. All rights reserved.
@contact:   Legato Tooling Team <letools@sierrawireless.com>
@license:   https://www.mozilla.org/en-US/MPL/2.0/
"""

from argparse import ArgumentParser

from leaf.core.error import LeafException

from .builders import CleanBuildTask, IndexBuildTask, MainBuildTask, PackBuildTask, SourceBuilder, SourceBuildTask
from .cmd import SettingUpdateAction
from .env import BuildSettings


class LinuxCleanBuild(CleanBuildTask):
    def build(self):
        if super().ask_for_artifacts_clean():
            self.shell_call('cd "$SWI_LINUX_CLONE" && make clean')


class LinuxToolchainCleanBuild(LinuxCleanBuild):
    def build(self):
        super().build()
        self.shell_call("rm -f $LEAF_BUILD_OUTPUT/${LEGATO_TARGET}-toolchain_*.leaf*")


class LinuxImageCleanBuild(LinuxCleanBuild):
    def build(self):
        super().build()
        self.shell_call("rm -f $LEAF_BUILD_OUTPUT/${LEGATO_TARGET}-linux*_*.leaf*")


class LinuxToolchainMainBuild(MainBuildTask):
    def build(self):
        super().build()
        self.shell_call('cd "$SWI_LINUX_CLONE" && make toolchain_bin' + self.main_build_opts)


class LinuxImageMainBuild(MainBuildTask):
    def build(self):
        super().build()
        self.shell_call('cd "$SWI_LINUX_CLONE" && make image_bin' + self.main_build_opts)


class LinuxToolchainPackBuild(PackBuildTask):
    def build(self):
        self.shell_call("$LEAF_BUILD_SCRIPTS/linux/pack-lxtoolchain.sh")


class LinuxImagePackBuild(PackBuildTask):
    def build(self):
        self.shell_call("$LEAF_BUILD_SCRIPTS/linux/pack-lximage.sh")


class LinuxSourceBuild(SourceBuildTask):
    def build(self):
        self.shell_call("$LEAF_BUILD_SCRIPTS/linux/pack-lxsource.sh")


class LinuxCommonBuilder(SourceBuilder):
    def __init__(self):
        SourceBuilder.__init__(self, "swi-linux", "SWI_LINUX_SRC", BuildSettings.SWI_LINUX_CLONE)

    def add_options(self, parser: ArgumentParser):
        # Need an option to specify Linux version
        parser.add_argument(
            "--version",
            metavar="VERSION",
            action=SettingUpdateAction,
            dest=BuildSettings.LINUX_VERSION.key,
            nargs=1,
            help="build leaf packages for Linux with specified VERSION",
        )

        # Make sure that machine option is managed
        parser.add_argument(
            "--mach", metavar="MACHINE", action=SettingUpdateAction, dest=BuildSettings.LINUX_MACH.key, nargs=1, help="build Linux for target MACHINE type"
        )

    def check_options(self, args, enabled_tasks):
        # Check enabled tasks
        is_packing = False
        is_building = False
        for task in enabled_tasks.values():
            if isinstance(task, PackBuildTask):
                is_packing = True
            if isinstance(task, MainBuildTask):
                is_building = True

        # Check if version is specified
        if is_packing and not BuildSettings.LINUX_VERSION.is_set():
            raise LeafException(
                message="Linux leaf packages version is not specified",
                hints=["Please use '--version' option", "or set '{0}' env var".format(BuildSettings.LINUX_VERSION.key)],
            )

        # Check if machine is specified
        if (is_packing or is_building) and not BuildSettings.LINUX_MACH.is_set():
            raise LeafException(
                message="Target machine type is not specified",
                hints=["Please use '--mach' option", "or set '{0}' env var".format(BuildSettings.LINUX_MACH.key)],
            )


class LinuxToolchainBuilder(LinuxCommonBuilder):
    def get_build_tasks(self):
        return [LinuxToolchainCleanBuild(), LinuxToolchainMainBuild(), LinuxToolchainPackBuild(), LinuxSourceBuild(), IndexBuildTask()]

    def add_options(self, parser: ArgumentParser):
        super().add_options(parser)

        # Need an option to specify target Host
        parser.add_argument(
            "--host",
            metavar="HOST",
            action=SettingUpdateAction,
            dest=BuildSettings.LINUX_HOST.key,
            nargs=1,
            help="build Linux toolchain for specified HOST architecture\n(defaults to current host's one)",
        )


class LinuxImageBuilder(LinuxCommonBuilder):
    def get_build_tasks(self):
        return [LinuxImageCleanBuild(), LinuxImageMainBuild(), LinuxImagePackBuild(), LinuxSourceBuild(), IndexBuildTask()]
