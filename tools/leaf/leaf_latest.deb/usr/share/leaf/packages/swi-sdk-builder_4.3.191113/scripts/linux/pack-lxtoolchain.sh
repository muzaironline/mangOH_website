#!/bin/bash
set -e
if test -n "$LEAF_DEBUG"; then set -x; fi

# Use common library
source "$LEAF_BUILD_SCRIPTS/linux/linux-common.sh"

# --------------------------------
# Build leaf package for toolchain
# --------------------------------

# Check for toolchain extractor
envSetHint="or set 'SWI_LINUX_TOOLCHAIN_INSTALLER' env var"
if test -z "$SWI_LINUX_TOOLCHAIN_INSTALLER"; then
    testSdkDeployDir

    # Look for one binary extractor
    getToolchainExtractor
    testString "$SWI_LINUX_TOOLCHAIN_INSTALLER" \
               "Can't find any $LEAF_BUILD_LINUX_HOST toolchain installer in $SWI_LINUX_YOCTO_SDK" \
               --hint "$LINUX_BUILD_HINT" \
               --hint "$TOOLCHAIN_BUILD_HINT" \
               --hint "$envSetHint"
    if test "$(echo "$SWI_LINUX_TOOLCHAIN_INSTALLER" | wc -l)" != "1"; then
        error "Too many $LEAF_BUILD_LINUX_HOST toolchain installers in $SWI_LINUX_YOCTO_SDK" \
              --hint "try to clean some" \
              --hint "$envSetHint"
    fi
fi
testFile "$SWI_LINUX_TOOLCHAIN_INSTALLER" \
         "Can't find expected toolchain installer: $SWI_LINUX_TOOLCHAIN_INSTALLER" \
         --hint "$LINUX_BUILD_HINT" \
         --hint "$TOOLCHAIN_BUILD_HINT" \
         --hint "$envSetHint"

# Reference file for package date will be the Toolchain installer
leafPackReferenceDateFile="${SWI_LINUX_TOOLCHAIN_INSTALLER}"

# Compute version
leafPackVersion="${SWI_LINUX_TOOLCHAIN_PACKAGE_VERSION}"

# Exports extra vars for manifest build
export yoctoSupportedOs="$LEAF_BUILD_LINUX_HOST"

# Setup manifest
LINUX_TOOLCHAIN_DESCRIPTION="${LINUX_TOOLCHAIN_DESCRIPTION:-GCC cross compiler Toolchain for ${moduleUpperShortName}}"
leafPackName="${moduleShortName}-toolchain"
leafPackDescription="${LINUX_TOOLCHAIN_DESCRIPTION}"
leafManifestExtraArgs=""
leafManifestTemplate="$LEAF_BUILD_SCRIPTS/templates/toolchain.json"
leafBuildManifest

# Ready to copy
bundleFile "$SWI_LINUX_TOOLCHAIN_INSTALLER" "toolChainExtractor.sh"
chmod +x "${SWI_LINUX_STAGING_DIR}/toolChainExtractor.sh"

# Ready to build package
leafBuildPackage
