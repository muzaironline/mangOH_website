"""
Legato SDK Builder

@author:    Legato Tooling Team <letools@sierrawireless.com>
@copyright: Sierra Wireless. All rights reserved.
@contact:   Legato Tooling Team <letools@sierrawireless.com>
@license:   https://www.mozilla.org/en-US/MPL/2.0/
"""

import subprocess
from collections import OrderedDict

from leaf.api import WorkspaceManager
from leaf.core.error import ProfileOutOfSyncException

from .env import BuildSettings
from .errors import EnvNotFoundException
from .compat import CSetting, get_env_list


class BuildManager:
    def __init__(self, wm: WorkspaceManager, builder):
        self.wm = wm

        # Can't do anything if no profile or if profile is not sync
        self.profile = self.wm.get_profile(self.wm.current_profile_name)
        if not self.wm.is_profile_sync(self.profile):
            raise ProfileOutOfSyncException(self.profile)
        self.full_env = self.wm.build_full_environment(self.profile)

        # Setup builder
        self.builder = builder

        # Refresh environment with settings and leaf env
        self.refresh_env()

        # Can't do anything if LEGATO_TARGET is not set
        self.legato_target

    def refresh_env(self):
        env = self.get_expanded_envmap()
        # Iterate on all entries in the leaf env
        for key in set(map(lambda tpl: tpl[0], get_env_list(self.full_env))):
            # Get potential matching setting
            setting = BuildSettings.get_by_key(key)
            if setting is None:
                # Well, it's not one of our known settings; make it a managed env var anyway
                setting = CSetting(key)
            if not BuildSettings.is_updated_from_args(setting.key):
                # Value wasn't overridden by CLI args --> contribute environment with resolved value
                setting.value = env[setting.key]

    def get_expanded_envmap(self):
        # Delegate environment resolution to a shell
        env_exports = ""
        for k, v in get_env_list(self.full_env):
            env_exports += 'export {0}="{1}"; '.format(k, v)
        out = {}
        for env_line in subprocess.check_output(["sh", "-c", env_exports + "env"]).decode().splitlines():
            split_pos = env_line.find("=")
            out[env_line[0:split_pos]] = env_line[split_pos + 1 :]
        return out

    @property
    def legato_target(self) -> str:
        if not BuildSettings.LEGATO_TARGET.is_set():
            raise EnvNotFoundException(BuildSettings.LEGATO_TARGET.key)
        return BuildSettings.LEGATO_TARGET.value

    @property
    def legato_target_short(self) -> str:
        full = self.legato_target
        short = full[:4]
        if short == "ar75":
            short = full
        return short

    def build(self, enabled_tasks):
        # Ask builder to perform some initial checks
        self.builder.setup(self)

        # Ask builder to perform build
        self.builder.build(OrderedDict(sorted(enabled_tasks.items(), key=lambda t: t[1].build_order)))
