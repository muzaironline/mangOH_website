"""
Legato SDK Builder

@author:    Legato Tooling Team <letools@sierrawireless.com>
@copyright: Sierra Wireless. All rights reserved.
@contact:   Legato Tooling Team <letools@sierrawireless.com>
@license:   https://www.mozilla.org/en-US/MPL/2.0/
"""

import subprocess
import sys
from abc import ABC, abstractmethod
from argparse import ArgumentParser

from .env import BuildSettings
from .errors import NotBuildableModuleException
from .compat import CSetting


class BuildTask(ABC):
    @abstractmethod
    def build(self):
        pass

    def set_build_manager(self, bm):
        self.bm = bm

    def shell_call(self, command):
        self.bm.wm.logger.print_verbose("Calling command: " + command)
        shcmd = ["/bin/sh", "-c", command]
        rc = subprocess.call(shcmd, stdout=None, stderr=subprocess.STDOUT)
        if rc != 0:
            sys.exit(rc)


class CleanBuildTask(BuildTask):
    def __init__(self):
        self.name = "clean"
        self.description = "Clean built artifacts and/or leaf packages"
        self.build_order = 10

    def ask_for_artifacts_clean(self):
        return self.bm.wm.print_with_confirm(question="Clean built artifacts in addition to leaf packages?")


class MainBuildTask(BuildTask):
    def __init__(self):
        self.name = "main"
        self.description = "Build artifacts to be bundled as leaf packages"
        self.build_order = 20

    def build(self):
        # Just setup options if necessary
        main_opts = BuildSettings.MAIN_OPTS.value
        self.main_build_opts = (" " + " ".join(main_opts.split(","))) if main_opts is not None else ""


class PackBuildTask(BuildTask):
    def __init__(self):
        self.name = "pack"
        self.description = "Build leaf packages from generated artifacts"
        self.build_order = 30


class SourceBuildTask(PackBuildTask):
    def __init__(self):
        self.name = "source"
        self.description = "Build source leaf package for current source code version"
        self.build_order = 40


class IndexBuildTask(BuildTask):
    def __init__(self):
        self.name = "index"
        self.description = "Refresh built leaf packages index"
        self.build_order = 50

    def build(self):
        # Refresh index
        description = BuildSettings.INDEX_DESCR.value
        description_option = "--description " + description if description is not None else ""
        self.shell_call('cd "$LEAF_BUILD_OUTPUT" && leaf build index {o} -o index.json *.leaf'.format(o=description_option))


class Builder(ABC):
    def __init__(self):
        self.bm = None

    @abstractmethod
    def get_build_tasks(self):
        pass

    # Perform build
    def build(self, enabled_tasks):
        for task in enabled_tasks.values():
            self.bm.wm.logger.print_default(">>> Building task: " + task.name)
            task.set_build_manager(self.bm)
            task.build()
        self.bm.wm.logger.print_default(">>> Build success")

    # To be implemented by subclasses

    def setup(self, bm):
        self.bm = bm

    def is_source_supported(self):
        return False

    def add_options(self, parser: ArgumentParser):
        # Nothing to do in default implementation
        pass

    def check_options(self, args, enabled_tasks):
        # Nothing to do in default implementation
        pass


class SourceBuilder(Builder):
    def __init__(self, name: str, env_name: str, custom_build_setting: CSetting):
        Builder.__init__(self)
        self.name = name
        self.env = CSetting(env_name)

        # Custom build location name
        self.custom_build_setting = custom_build_setting

    # Is toggled in source mode?
    def is_source_toggled(self):
        return self.env.is_set()

    # Setup for source based builders
    def setup(self, bm):
        # Super call
        super().setup(bm)

        # Get information about related env var
        self.bm.wm.logger.print_verbose("Checking source feature value for {0}: {1}".format(self.name, self.env.value))

        # Check if source mode is enabled or custom build location is set
        if not self.is_source_toggled() and not self.custom_build_setting.is_set():
            # We don't know where to build this module
            raise NotBuildableModuleException(self)
