# Common library for Legato packages build

# Get builders common library
source ${LEAF_BUILD_SCRIPTS}/leaf-build-common.sh

# Some common hints
LEGATO_RELEASE_HINT="Try to trigger release build with 'releaselegato -t \$LEGATO_TARGET'"
LEGATO_BUILD_HINT="Try to trigger build with 'make -C \$LEGATO_ROOT \$LEGATO_TARGET'"
LEGATO_DOC_HINT="Try to trigger documentation build with 'make -C \$LEGATO_ROOT user_docs'"

# Build dir setup
LEGATO_BUILD_DIR="${LEGATO_ROOT}/build/${LEGATO_TARGET}"
testDir "${LEGATO_BUILD_DIR}" \
        "Can't find Legato build dir for current target: ${LEGATO_BUILD_DIR}" \
        --hint "$LEGATO_BUILD_HINT"
LEGATO_BUILT_IMAGE="${LEGATO_BUILD_DIR}/legato.cwe"
testFile "${LEGATO_BUILT_IMAGE}" \
         "Can't find Legato built image for current target: ${LEGATO_BUILT_IMAGE}" \
         --hint "$LEGATO_BUILD_HINT"

# Release dir setup
LEGATO_RELEASE_DIR=${LEGATO_RELEASE_DIR:-${LEGATO_ROOT}/releases}
testDir "${LEGATO_RELEASE_DIR}" \
        "Can't find Legato release directory: ${LEGATO_RELEASE_DIR}" \
        --hint "$LEGATO_RELEASE_HINT"

# Legato image setup
LEGATO_IMAGE="${LEGATO_RELEASE_DIR}/legato-${LEGATO_TARGET}.cwe"
testFile "${LEGATO_IMAGE}" \
         "Can't find Legato image for current target: ${LEGATO_IMAGE}" \
         --hint "$LEGATO_RELEASE_HINT"

# User documentation
initLegatoDocDir() {
    LEGATO_DOC_DIR="${LEGATO_ROOT}/Documentation"
    testDir "${LEGATO_DOC_DIR}" \
            "Can't find Legato user documentation dir: ${LEGATO_DOC_DIR}" \
            --hint "$LEGATO_DOC_HINT"
}

# Staging dir setup
LEGATO_STAGING_DIR=$(mktemp -d)
leafPackStagingDir="${LEGATO_STAGING_DIR}"

# Legato version setup
if test -z "$LEAF_BUILD_LEGATO_VERSION"; then
    LEGATO_VERSION_FILE=${LEGATO_ROOT}/version
    testFile "$LEGATO_VERSION_FILE" \
             "Can't find Legato version file: $LEGATO_VERSION_FILE" \
             --hint "$LEGATO_BUILD_HINT" \
             --hint "or configure the LEAF_BUILD_LEGATO_VERSION with 'leaf env workspace --set LEAF_BUILD_LEGATO_VERSION=AA.BB.C'"
    LEAF_BUILD_LEGATO_VERSION="$(cat $LEGATO_VERSION_FILE)"
fi

# Split version prefix and suffix if not exactly on a tag
legatoVersionRegexp="\(.*\)-\([0-9]*-g[0-9a-f]*\)"
LEGATO_VERSION_PREFIX="$(echo $LEAF_BUILD_LEGATO_VERSION | sed -e "s/$legatoVersionRegexp/\1/")"
if test -n "$LEGATO_VERSION_PREFIX" -a "$LEGATO_VERSION_PREFIX" != "$LEAF_BUILD_LEGATO_VERSION"; then
    LEGATO_VERSION_SUFFIX="-$(echo $LEAF_BUILD_LEGATO_VERSION | sed -e "s/$legatoVersionRegexp/\2/")"
else
    LEGATO_VERSION_PREFIX="$LEAF_BUILD_LEGATO_VERSION"
    LEGATO_VERSION_SUFFIX=""
    LEGATO_VERSION_ISTAG=1
fi
if test -n "${LEGATO_BUILD_VARIANT}"; then
    # Append build variant to version, if any
    LEGATO_VERSION_SUFFIX="${LEGATO_VERSION_SUFFIX}-${LEGATO_BUILD_VARIANT}"
fi

# Used date chart, according to stream type
#
#   Stream:         Internal        Dev             Stable
#
#   Package Type:
#
#   legato          tag image       rebuilt image   tag image       (LEGATO_BUILT_IMAGE)
#
#   legato-img      tag image       rebuilt image   product image   (LEGATO_IMAGE)
#
#   legato-src      doc index       doc index       doc index

# Compute Legato package version
defaultLegatoVersion="${LEGATO_VERSION_PREFIX}-$(date -u -r ${LEGATO_BUILT_IMAGE} +%Y%m%d%H%M)${LEGATO_VERSION_SUFFIX}"
LEGATO_PACKAGE_VERSION="${LEGATO_PACKAGE_VERSION:-${defaultLegatoVersion}}"

# Compute Legato image version
defaultLegatoImgVersion="${LEGATO_VERSION_PREFIX}-$(date -u -r ${LEGATO_IMAGE} +%Y%m%d%H%M)${LEGATO_VERSION_SUFFIX}"
LEGATO_IMG_PACKAGE_VERSION="${LEGATO_IMG_PACKAGE_VERSION:-${defaultLegatoImgVersion}}"

# Compute repo type
LEAF_BUILD_REPO_TYPE=${LEAF_BUILD_REPO_TYPE:-external}
if echo "$LEAF_BUILD_LEGATO_VERSION" | grep -q ".rc"; then
    # Let's consider all .rc builds (including dev ones) as pointing to internal Gerrit
    LEAF_BUILD_REPO_TYPE="internal"
fi

# Compute Legato source version
defaultLegatoSrcVersion=${LEAF_BUILD_LEGATO_VERSION}
if test "$LEAF_BUILD_REPO_TYPE" = "internal"; then
    defaultLegatoSrcVersion="${defaultLegatoSrcVersion}-internal"
fi
LEGATO_SRC_PACKAGE_VERSION="${LEGATO_SRC_PACKAGE_VERSION:-${defaultLegatoSrcVersion}}"
