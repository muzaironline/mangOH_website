"""
Legato SDK Builder

@author:    Legato Tooling Team <letools@sierrawireless.com>
@copyright: Sierra Wireless. All rights reserved.
@contact:   Legato Tooling Team <letools@sierrawireless.com>
@license:   https://www.mozilla.org/en-US/MPL/2.0/
"""
from leaf.model.workspace import Profile
from leaf.model.environment import Environment

# Compatibility layer for SDK builder commands

# Try to import leaf 2.0 EnvVar class
try:
    from leaf.core.settings import EnvVar

    class CSetting(EnvVar):
        pass


except ImportError:
    # Ok, we're probably on an older leaf: use "Setting" instead
    from leaf.core.settings import Setting

    class CSetting(Setting):
        pass


# Get packages map from profiles
def compat_get_packages(profile: Profile):
    if hasattr(profile, "pkg_map"):
        return profile.pkg_map
    else:
        return profile.packages_map


# Get environment list
def get_env_list(env: Environment):
    if hasattr(env, "tolist"):
        return env.tolist()
    else:
        env_list = []
        env.activate(kv_consumer=lambda k, v: env_list.append((k, v)))
        return env_list
