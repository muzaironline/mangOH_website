#!/bin/bash
set -e
if test -n "$LEAF_DEBUG"; then set -x; fi

# Use common library
source "$LEAF_BUILD_SCRIPTS/legato/legato-common.sh"

# ------------------------------------
# Build leaf package for legato source
# ------------------------------------

# Test for a version suffix
if test -z "${LEGATO_VERSION_ISTAG}"; then
    # We're not on a tag; meaningless to build source package
    error "Looks like Legato version is not based on a tag: ${LEAF_BUILD_LEGATO_VERSION}" \
          --hint "try to build a tag version" \
          --hint "or force 'LEAF_BUILD_LEGATO_VERSION' variable"
fi

# Compute version
leafPackVersion="${LEGATO_SRC_PACKAGE_VERSION}"

# Reference file for package date will be the Legato doc index
# (since it is independent from rebuilds)
initLegatoDocDir
leafPackReferenceDateFile="${LEGATO_DOC_DIR}/index.html"

# Prereqs
leafManifestExtraArgs="--requires swi-aptdeps-legato-src_latest"

# Extra variables export for manifest build
export legatoVersion=${LEAF_BUILD_LEGATO_VERSION}
export repoType=${LEAF_BUILD_REPO_TYPE}

# Manage License post install
checkLicensePostInstallStep

# Setup manifest
LEGATO_SOURCE_DESCRIPTION="${LEGATO_SOURCE_DESCRIPTION:-Legato source code metadata and prerequisites}"
leafPackName="${moduleShortName}-legato-src"
leafPackDescription="${LEGATO_SOURCE_DESCRIPTION}"
leafManifestExtraArgs="$leafManifestExtraArgs --requires $swiVerifyDeps --depends swi-cloneutils_latest"
leafManifestTemplate="$LEAF_BUILD_SCRIPTS/templates/legato-src.json"
leafBuildManifest

# Ready to build package
leafBuildPackage -j
