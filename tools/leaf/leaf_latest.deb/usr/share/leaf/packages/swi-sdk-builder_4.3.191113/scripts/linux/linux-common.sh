# Common library for Linux packages build

# Get builders common library
source ${LEAF_BUILD_SCRIPTS}/leaf-build-common.sh

# Common hints
LINUX_BUILD_HINT="try to use 'main' build task"
TOOLCHAIN_BUILD_HINT="or run 'make toolchain_bin' in 'SWI_LINUX_CLONE' folder"
IMAGE_BUILD_HINT="or run 'make image_bin' in 'SWI_LINUX_CLONE' folder"

# Check host
LEAF_BUILD_LINUX_HOST=${LEAF_BUILD_LINUX_HOST:-x86_64}

# Basic deployment dirs
SWI_LINUX_YOCTO_DEPLOY=${SWI_LINUX_YOCTO_DEPLOY:-${SWI_LINUX_CLONE}/build_bin/tmp/deploy}

# Check build output
SWI_LINUX_YOCTO_SDK=${SWI_LINUX_YOCTO_SDK:-${SWI_LINUX_YOCTO_DEPLOY}/sdk}
testSdkDeployDir() {
    testDir "$SWI_LINUX_YOCTO_SDK" \
            "Can't find toolchain build output directory: $SWI_LINUX_YOCTO_SDK" \
            --hint "$LINUX_BUILD_HINT" \
            --hint "$TOOLCHAIN_BUILD_HINT"
}
SWI_LINUX_YOCTO_IMAGE=${SWI_LINUX_YOCTO_IMAGE:-${SWI_LINUX_YOCTO_DEPLOY}/images/swi-${MACH}}
testImageDeployDir() {
    testDir "$SWI_LINUX_YOCTO_IMAGE" \
            "Can't find images build output directory: $SWI_LINUX_YOCTO_IMAGE" \
            --hint "$LINUX_BUILD_HINT" \
            --hint "$IMAGE_BUILD_HINT"
}

# Toolchain extractor access
getToolchainExtractor() {
    extractors="$(find $SWI_LINUX_YOCTO_SDK -name '*.sh' 2>/dev/null | grep $LEAF_BUILD_LINUX_HOST || true)"
    SWI_LINUX_TOOLCHAIN_INSTALLER="$extractors"
}

# Compute Linux image and source versions
defaultLinuxImageVersion=${LEAF_BUILD_LINUX_VERSION}
defaultLinuxSrcVersion=${LEAF_BUILD_LINUX_VERSION}
if test "$LEAF_BUILD_REPO_TYPE" = "internal" -a -n "$LINUX_PRODUCT" -a ! "$LINUX_PRODUCT" = "lxswi"; then
    defaultLinuxImageVersion="${defaultLinuxImageVersion}-unsigned"
    defaultLinuxSrcVersion="${defaultLinuxSrcVersion}-internal"
fi
SWI_LINUX_IMAGE_PACKAGE_VERSION="${SWI_LINUX_IMAGE_PACKAGE_VERSION:-${defaultLinuxImageVersion}}"
SWI_LINUX_SRC_PACKAGE_VERSION="${SWI_LINUX_SRC_PACKAGE_VERSION:-${defaultLinuxSrcVersion}}"

# Compute Linux toolchain version from input ver + host
versionSuffix=linux64
if test "$LEAF_BUILD_LINUX_HOST" != "x86_64"; then
    versionSuffix=linux32
fi
defaultLinuxToolchainVersion="${LEAF_BUILD_LINUX_VERSION}-$versionSuffix"
SWI_LINUX_TOOLCHAIN_PACKAGE_VERSION="${SWI_LINUX_TOOLCHAIN_PACKAGE_VERSION:-${defaultLinuxToolchainVersion}}"

# Staging dir setup
SWI_LINUX_STAGING_DIR=$(mktemp -d)
leafPackStagingDir="${SWI_LINUX_STAGING_DIR}"
