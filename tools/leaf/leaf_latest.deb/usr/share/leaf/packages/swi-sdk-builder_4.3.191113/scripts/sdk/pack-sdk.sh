#!/bin/bash
set -e
if test -n "$LEAF_DEBUG"; then set -x; fi

# Use common library
source "$LEAF_BUILD_SCRIPTS/sdk/sdk-common.sh"

# --------------------------
# Build leaf package for SDK
# --------------------------

# Iterate on dependencies
leafManifestExtraArgs="$leafManifestExtraArgs --master true"
depVars="$LEAF_BUILD_SDK_DEP_LEGATO
$LEAF_BUILD_SDK_DEP_LEGATO_SRC
$LEAF_BUILD_SDK_DEP_TOOLCHAIN32
$LEAF_BUILD_SDK_DEP_TOOLCHAIN64
$LEAF_BUILD_SDK_DEP_FULL_IMG
$LEAF_BUILD_SDK_DEP_MODEM_IMG
$LEAF_BUILD_SDK_DEP_LEGATO_IMG
$LEAF_BUILD_SDK_DEP_LINUX_IMG
$LEAF_BUILD_SDK_DEP_LINUX_SRC"
for depVar in $depVars; do
    leafManifestExtraArgs="$leafManifestExtraArgs --depends $depVar"
done

# Handle signed modem image
modemImgVersion="$(extractVersion $LEAF_BUILD_SDK_DEP_MODEM_IMG)"
__handleSignedModem

# Manage License post install
checkLicensePostInstallStep

# Reference file for package date will be the Legato package
LEGATO_PACKAGE="$LEAF_BUILD_OUTPUT/${LEAF_BUILD_SDK_DEP_LEGATO%(*}.leaf"
testFile "$LEGATO_PACKAGE" \
         "Can't find custom Legato package to setup SDK timestamp: $LEGATO_PACKAGE"
leafPackReferenceDateFile="$LEGATO_PACKAGE"

# Legacy: if legato <= 1801, manage LEGATO_SYSROOT variable
legatoVersion="$(extractVersion $LEAF_BUILD_SDK_DEP_LEGATO)"
declare -i legatoDigits
legatoDigits=$(echo ${legatoVersion} | sed -e "s/\(..\)\.\(..\)\..*/\1\2/")
if (( $legatoDigits <= 1801 )); then
    leafManifestExtraArgs="$leafManifestExtraArgs --append $LEAF_BUILD_SCRIPTS/templates/sdk-extra.json"
fi

# Extract doc version from Legato version
export legatoDocsVersion=$(echo ${legatoVersion} | sed -e "s/\(..\)\.\(..\)\..*/\1_\2/")

# Setup manifest
leafManifestExtraArgs="$leafManifestExtraArgs --depends swi-legato_latest"
LEAF_BUILD_SDK_DESCRIPTION="${LEAF_BUILD_SDK_DESCRIPTION:-SDK for ${moduleUpperShortName}}${SDK_LABEL}"
leafPackName="${LEAF_BUILD_SDK_PREFIX}-${moduleShortName}"
leafPackDescription="${LEAF_BUILD_SDK_DESCRIPTION}"
leafManifestTemplate="$LEAF_BUILD_SCRIPTS/templates/sdk.json"
leafBuildManifest

# Ready to build package
leafBuildPackage -j
