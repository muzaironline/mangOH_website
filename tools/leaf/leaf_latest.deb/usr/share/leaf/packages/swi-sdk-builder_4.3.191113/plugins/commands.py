#! /usr/bin/python3
'''
Legato Builder

@author:    Legato Tooling Team <letools@sierrawireless.com>
@copyright: Sierra Wireless. All rights reserved.
@contact:   Legato Tooling Team <letools@sierrawireless.com>
@license:   https://www.mozilla.org/en-US/MPL/2.0/
'''

from .swi.builder.cmd import BuilderCommand
from .swi.builder.legato import LegatoBuilder
from .swi.builder.linux import LinuxImageBuilder, LinuxToolchainBuilder
from .swi.builder.sdk import SdkBuilder


class LegatoBuildCommand(BuilderCommand):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, builder=LegatoBuilder(), **kwargs)


class LinuxImageBuildCommand(BuilderCommand):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, builder=LinuxImageBuilder(), **kwargs)


class LinuxToolchainBuildCommand(BuilderCommand):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, builder=LinuxToolchainBuilder(), **kwargs)


class SdkBuildCommand(BuilderCommand):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, builder=SdkBuilder(), **kwargs)
