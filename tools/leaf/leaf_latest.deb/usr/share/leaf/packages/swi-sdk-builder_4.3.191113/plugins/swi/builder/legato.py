"""
Legato SDK Builder

@author:    Legato Tooling Team <letools@sierrawireless.com>
@copyright: Sierra Wireless. All rights reserved.
@contact:   Legato Tooling Team <letools@sierrawireless.com>
@license:   https://www.mozilla.org/en-US/MPL/2.0/
"""

from .builders import CleanBuildTask, IndexBuildTask, MainBuildTask, PackBuildTask, SourceBuilder, SourceBuildTask
from .env import BuildSettings


class LegatoCleanBuild(CleanBuildTask):
    def build(self):
        if super().ask_for_artifacts_clean():
            self.shell_call("make -C $LEGATO_ROOT clean")
            self.shell_call("rm -Rf $LEGATO_ROOT/releases")
        self.shell_call("rm -f $LEAF_BUILD_OUTPUT/${LEGATO_TARGET}-legato*.leaf*")


class LegatoMainBuild(MainBuildTask):
    def build(self):
        super().build()
        self.shell_call("make -C $LEGATO_ROOT $LEGATO_TARGET" + self.main_build_opts)
        self.shell_call("make -C $LEGATO_ROOT user_docs")
        self.shell_call("$LEAF_BUILD_SCRIPTS/legato/create-legato-release.sh")


class LegatoPackBuild(PackBuildTask):
    def __init__(self, build_pack, build_image, name=None, description=None, build_order=None):
        self.build_pack = build_pack
        self.build_image = build_image
        if name is not None:
            self.name = name
            self.description = description
            self.build_order = build_order
        else:
            PackBuildTask.__init__(self)

    def build(self):
        if self.build_pack:
            self.shell_call("$LEAF_BUILD_SCRIPTS/legato/pack-legato.sh")
        if self.build_image:
            self.shell_call("$LEAF_BUILD_SCRIPTS/legato/pack-legatoimage.sh")


class LegatoSourceBuild(SourceBuildTask):
    def build(self):
        self.shell_call("$LEAF_BUILD_SCRIPTS/legato/pack-legatosource.sh")


class LegatoBuilder(SourceBuilder):
    def __init__(self):
        SourceBuilder.__init__(self, "legato", "LEGATO_SRC", BuildSettings.LEGATO_CLONE)

    def get_build_tasks(self):
        return [
            LegatoCleanBuild(),
            LegatoMainBuild(),
            LegatoPackBuild(True, True),
            LegatoPackBuild(True, False, name="pack-fw", description="Build only leaf package for Legato framework", build_order=25),
            LegatoPackBuild(False, True, name="pack-img", description="Build only leaf package for Legato image", build_order=27),
            LegatoSourceBuild(),
            IndexBuildTask(),
        ]
