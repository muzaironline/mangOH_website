#!/bin/bash
set -e
if test -n "$LEAF_DEBUG"; then set -x; fi

# Use common library
source "$LEAF_BUILD_SCRIPTS/linux/linux-common.sh"

# -----------------------------------
# Build leaf package for linux source
# -----------------------------------

# Compute repo type
LEAF_BUILD_REPO_TYPE=${LEAF_BUILD_REPO_TYPE:-external}

# Compute version
leafPackVersion="${SWI_LINUX_SRC_PACKAGE_VERSION}"

# Handle specific sub-path for specific modules
case $module in
    wp85|wp750x)    linuxSrcModule=wp85xx
                    linuxSysrootProductSuffix=wp ;;
    wp76xx|wp77xx)  linuxSrcModule=$module
                    linuxSysrootProductSuffix=wp ;;
    ar*)            linuxSrcModule=$module
                    linuxSysrootProductSuffix=$module ;;
    *)  error "Internal error: don't know what to do with $module when computing source metadata"
esac

# Check machine definition
testString "$MACH" \
           "Machine type is not set (can't guess it)" \
           --hint "Please set 'MACH' env var"

# Handle specific manifest product for (internal) LXSWI distribution
if test -n "$LINUX_PRODUCT" -a "$LINUX_PRODUCT" = "lxswi"; then
    linuxSrcProduct="lxswi"
    linuxDeployProduct="lxswi"
else
    linuxSrcProduct="${MACH}"
    linuxDeployProduct="swi-${MACH}-${linuxSysrootProductSuffix}"
fi

# Extra variables export for manifest build
export linuxSrcModule
export linuxSrcProduct
export linuxDeployProduct
export version=${SWI_LINUX_SRC_PACKAGE_VERSION}
export repoType=${LEAF_BUILD_REPO_TYPE}
export mach=${MACH}

getToolchainExtractor
if test -n "$SWI_LINUX_TOOLCHAIN_INSTALLER" -a "$(echo "$SWI_LINUX_TOOLCHAIN_INSTALLER" | wc -l)" = "1"; then
    # Use toolchain extractor as reference date file
    leafPackReferenceDateFile="$SWI_LINUX_TOOLCHAIN_INSTALLER"
else
    # Reference file for package date will be the staging dir
    leafPackReferenceDateFile="$leafPackStagingDir"
fi

# Manage License post install
checkLicensePostInstallStep

# Setup manifest
SWI_LINUX_SOURCE_DESCRIPTION="${SWI_LINUX_SOURCE_DESCRIPTION:-Linux distribution source code metadata and prerequisites}"
leafPackName="${moduleShortName}-linux-src"
leafPackDescription="${SWI_LINUX_SOURCE_DESCRIPTION}"
leafManifestExtraArgs="$leafManifestExtraArgs --requires swi-aptdeps-linux-src_latest --requires $swiVerifyDeps --depends swi-cloneutils_latest"
leafManifestTemplate="$LEAF_BUILD_SCRIPTS/templates/linux-src.json"
leafBuildManifest

# Ready to build package
leafBuildPackage -j
