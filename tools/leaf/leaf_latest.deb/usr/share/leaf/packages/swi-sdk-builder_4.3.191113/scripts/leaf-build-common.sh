# Shell lib for builders

# Error message and hints
# error $MSG $HINT...
error() {
    local MSG="${1}"
    shift
    $LEAF_BUILD_SCRIPTS/leaf-error -m "${MSG}" "$@"
    exit 1
}

# Test directory existence
# testDir $DIR $MSG $HINT...
testDir() {
    local DIR="${1}"
    shift
    local MSG="${1}"
    shift
    if test ! -d "${DIR}"; then
        error "${MSG}" "$@"
    fi
}

# Test file existence
# testFile $FILE $MSG $HINT...
testFile() {
    local FILE="${1}"
    shift
    local MSG="${1}"
    shift
    if test ! -f "${FILE}"; then
        error "${MSG}" "$@"
    fi
}

# Test string
# testString $STR $MSG $HINT...
testString() {
    local STR="${1}"
    shift
    local MSG="${1}"
    shift
    if test -z "${STR}"; then
        error "${MSG}" "$@"
    fi
}

# Bundle with some trace messages
bundleFile() {
    local toCopy="$1"
    local destFileName="$2"
    if test "${LEAF_VERBOSE}" != "quiet"; then
        echo "Adding $toCopy to leaf package..."
    fi
    cp -p -L "$toCopy" "$leafPackStagingDir/$destFileName"
}

# Manifest build
leafBuildManifest() {
    # Export used variables
    export module
    export moduleUpperName
    export moduleUpperShortName
    export moduleShortName

    # Compute release date
    local releaseDate="$(export LANG=en_EN.UTF-8; date -r $leafPackReferenceDateFile -u)"

    # Compute license options
    local extraLicenseOpts=""
    if test -z "$LEAF_BUILD_LICENSE_NONE"; then
        extraLicenseOpts="--requires $LEAF_BUILD_LICENSE_NAME --requires swi-verify-license_latest"
    fi

    # Compute extra tags
    local extraTagsOpts=""
    if test -n "$LEAF_BUILD_EXTRA_TAGS"; then
        local extraTag
        for extraTag in $(echo $LEAF_BUILD_EXTRA_TAGS | sed -e "s/,/ /g"); do
            extraTagsOpts="$extraTagsOpts --tag $extraTag"
        done
    fi

    # Compute index tags
    if test -n "$LEAF_BUILD_INDEX_TAGS"; then
        local outputLeafTags="${LEAF_BUILD_OUTPUT}/${leafPackName}_${leafPackVersion}.leaf.tags"
        rm -f $outputLeafTags
        local indexTag
        for indexTag in $(echo $LEAF_BUILD_INDEX_TAGS | sed -e "s/,/ /g"); do
            echo "$indexTag" >> $outputLeafTags
        done
    fi

    # Generate manifest
    leaf build manifest \
        -o $leafPackStagingDir \
        --name $leafPackName \
        --version $leafPackVersion \
        --description "$leafPackDescription" \
        --minver $leafMinVersion \
        --date "$releaseDate" \
        --tag $module \
        $extraTagsOpts \
        $extraLicenseOpts \
        --append "$leafManifestTemplate" \
        --env \
        $leafManifestExtraArgs
}

# Package build
leafBuildPackage() {
    local compression="$1"
    local outputLeaf="${LEAF_BUILD_OUTPUT}/${leafPackName}_${leafPackVersion}.leaf"

    # If there is a packaging hook defined, call it
    if test -n "$LEAF_BUILD_PREPACK_HOOK"; then
        local hookRC=0
        "$LEAF_BUILD_PREPACK_HOOK" "$leafPackStagingDir" || hookRC=$?
        if test "$hookRC" != 0; then
            error "Prepack hook call failed with RC $hookRC"
        fi
    fi

    # Info files build option
    local infoOpt="--no-info"
    if test -n "$LEAF_BUILD_INFO"; then
        infoOpt=""
    fi

    # Tar sort option (quite a recent one; not present on Ubuntu 14.04)
    local tarSortOption=""
    if tar --help | grep "\--sort" > /dev/null; then
        tarSortOption="--sort name"
    fi

    # Ready to pack
    mkdir -p "${LEAF_BUILD_OUTPUT}"
    leaf build pack \
        $infoOpt \
        -o $outputLeaf \
        -i $leafPackStagingDir -- \
        --mtime="$(date -R -r $leafPackReferenceDateFile -u)" \
        $compression \
        --mode='a+r,a-w,u+w' \
        --owner=0 --group=0 --numeric-owner \
        $tarSortOption \
        .
    touch -c -r $leafPackReferenceDateFile $outputLeaf
}

# License post install step (for Sierra license)
checkLicensePostInstallStep() {
    if test -z "$LEAF_BUILD_LICENSE_NONE"; then
        USE_LICENSE_CHECK_FRAGMENT=1
    fi
}

# Perform some initial verifications
testString "${LEAF_WORKSPACE}" \
           "Looks like we're not in a Leaf workspace" \
           --hint "Go to a Leaf workspace directory and call 'leaf shell'"

# Prepare module variables
module=${LEGATO_TARGET}

# Computing all flavors of module strings
moduleUpperName=$(echo $module | tr '[:lower:]' '[:upper:]')
moduleShortName=${module:0:4}
if test "$moduleShortName" = "ar75"; then
    # Keep long version for AR758X/AR759X packages
    moduleShortName=$module
fi

# Override module short name if requested
if test -n "${LEAF_BUILD_MODULE_OVERRIDE}"; then
    moduleShortName="${LEAF_BUILD_MODULE_OVERRIDE}"
fi
moduleUpperShortName=$(echo $moduleShortName | tr '[:lower:]' '[:upper:]')

# Some shared constants
leafMinVersion="1.6"                        # Minimum leaf version to tag packages with
swiVerifyDeps="swi-verify-aptdeps_latest"   # ID of APT dependencies verifier utility package
