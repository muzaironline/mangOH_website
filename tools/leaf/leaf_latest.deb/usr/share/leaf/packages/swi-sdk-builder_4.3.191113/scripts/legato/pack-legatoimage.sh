#!/bin/bash
set -e
if test -n "$LEAF_DEBUG"; then set -x; fi

# Use common library
source "$LEAF_BUILD_SCRIPTS/legato/legato-common.sh"

# -----------------------------------
# Build leaf package for legato image
# -----------------------------------

# Compute version
leafPackVersion="${LEGATO_IMG_PACKAGE_VERSION}"

# Reference file for package date will be the Legato image
leafPackReferenceDateFile="${LEGATO_IMAGE}"

# Setup manifest
LEGATO_IMAGE_DESCRIPTION="${LEGATO_IMAGE_DESCRIPTION:-Legato Image for ${moduleUpperShortName}}"
leafPackName="${moduleShortName}-legato-image"
leafPackDescription="${LEGATO_IMAGE_DESCRIPTION}"
leafManifestExtraArgs=""
leafManifestTemplate="$LEAF_BUILD_SCRIPTS/templates/legato-image.json"
leafBuildManifest

# RW image
LEGATO_RW_IMAGE="${LEGATO_RELEASE_DIR}/legato_rw-${LEGATO_TARGET}.cwe"
testFile "${LEGATO_RW_IMAGE}" \
         "Can't find Legato RW image for current target: ${LEGATO_RW_IMAGE}" \
         --hint "$LEGATO_RELEASE_HINT"

# Are the RW/RO images really different?
if diff "${LEGATO_IMAGE}" "${LEGATO_RW_IMAGE}"; then
    # Same think: bundle only one image
    bundleFile "${LEGATO_IMAGE}" "legato.cwe"
else
    # Bundle both different images
    bundleFile "${LEGATO_IMAGE}" "legato_ro.cwe"
    bundleFile "${LEGATO_RW_IMAGE}" "legato_rw.cwe"
fi

# Ready to build package
leafBuildPackage -j
