"""
Legato SDK Builder

@author:    Legato Tooling Team <letools@sierrawireless.com>
@copyright: Sierra Wireless. All rights reserved.
@contact:   Legato Tooling Team <letools@sierrawireless.com>
@license:   https://www.mozilla.org/en-US/MPL/2.0/
"""
from leaf.core.settings import StaticSettings
from .compat import CSetting


class BuildSettings(StaticSettings):
    # Common settings
    SCRIPTS_ROOT = CSetting("LEAF_BUILD_SCRIPTS")
    INFO = CSetting("LEAF_BUILD_INFO")
    LICENSE_NONE = CSetting("LEAF_BUILD_LICENSE_NONE")
    LICENSE_NAME = CSetting("LEAF_BUILD_LICENSE_NAME")
    INDEX_DESCR = CSetting("LEAF_INDEX_DESCRIPTION")
    OUTPUT = CSetting("LEAF_BUILD_OUTPUT")
    EXTRA_TAGS = CSetting("LEAF_BUILD_EXTRA_TAGS")
    INDEX_TAGS = CSetting("LEAF_BUILD_INDEX_TAGS")
    MAIN_OPTS = CSetting("LEAF_BUILD_MAIN_OPTS")
    MODULE = CSetting("LEAF_BUILD_MODULE_OVERRIDE")

    # Legato builder settings
    LEGATO_CLONE = CSetting("LEGATO_CLONE")
    LEGATO_TARGET = CSetting("LEGATO_TARGET")
    LEGATO_VERSION = CSetting("LEAF_BUILD_LEGATO_VERSION")

    # Linux builder settings
    SWI_LINUX_CLONE = CSetting("SWI_LINUX_CLONE")
    LINUX_MACH = CSetting("MACH")
    LINUX_VERSION = CSetting("LEAF_BUILD_LINUX_VERSION")
    LINUX_HOST = CSetting("LEAF_BUILD_LINUX_HOST")

    # SDK builder settings
    SDK_PREFIX = CSetting("LEAF_BUILD_SDK_PREFIX")
    SDK_VERSION = CSetting("LEAF_BUILD_SDK_VERSION")

    # "Args updated" map
    __updated_from_args = {}

    @classmethod
    def updated_from_args(cls, key: str):
        if cls.get_by_key(key) is not None:
            cls.__updated_from_args[key] = True

    @classmethod
    def is_updated_from_args(cls, key: str) -> bool:
        return cls.__updated_from_args[key] if key in cls.__updated_from_args.keys() else False
