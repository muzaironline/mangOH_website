#!/usr/bin/env python3
# LEAF_DESCRIPTION build a customized Legato SDK from current profile
"""
Legato SDK Builder

@author:    Legato Tooling Team <letools@sierrawireless.com>
@copyright: Sierra Wireless. All rights reserved.
@contact:   Legato Tooling Team <letools@sierrawireless.com>
@license:   https://www.mozilla.org/en-US/MPL/2.0/
"""

import argparse
from collections import OrderedDict

from leaf.cli.cliutils import EnvSetterAction
from leaf.cli.plugins import LeafPluginCommand
from leaf.model.package import PackageIdentifier
from leaf.model.modelutils import is_latest_package, find_latest_version

from .builders import Builder, MainBuildTask, PackBuildTask
from .env import BuildSettings
from .errors import LicenseInfoException, UnknownBuildTaskException, UnknownLicenseException
from .manager import BuildManager


class SettingUpdateAction(EnvSetterAction):
    def __call__(self, *args, **kwargs):
        super().__call__(*args, **kwargs)
        BuildSettings.updated_from_args(self.dest)


class BuildTask:
    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description


class BuilderCommand(LeafPluginCommand):
    def __init__(self, *args, builder: Builder = None, **kwargs):
        super().__init__(*args, **kwargs)
        self.tasks = {}
        self.builder = builder

        # Setup build tasks exposed by the builder
        # (We need the tasks to be referenced before the parser is created)
        self.add_tasks(self.builder.get_build_tasks())

    def add_tasks(self, tasks):
        # Simply get them from builder
        for task in tasks:
            self.tasks[task.name] = task

    def contains_task(self, task_class, tasks=None):
        # Loop on tasks list and match if given instance is found
        for task in tasks if tasks is not None else self.tasks.values():
            if isinstance(task, task_class):
                return True
        return False

    def get_tasks_description(self):
        # Loop and display tasks descriptions
        out = ""
        for task in OrderedDict(sorted(self.tasks.items(), key=lambda t: t[1].build_order)).values():
            out += "\n" if len(out) > 0 else ""
            out += "  {name}: {descr}".format(name=task.name, descr=task.description)
        return out

    def _get_epilog_text(self):
        return "Supported build tasks are:\n" + self.get_tasks_description()

    def _configure_parser(self, parser):
        super()._configure_parser(parser)

        # Arguments parsing
        parser.add_argument("tasks", metavar="TASK", nargs=argparse.ONE_OR_MORE, help="build task to be executed (see below)")
        if self.contains_task(MainBuildTask):
            parser.add_argument(
                "-m",
                "--main-option",
                action=SettingUpdateAction,
                dest=BuildSettings.MAIN_OPTS.key,
                nargs=argparse.ONE_OR_MORE,
                const=",",
                metavar="OPTION",
                help="add OPTION to make command line when running main build task",
            )
        parser.add_argument(
            "-o", "--output", metavar="FOLDER", action=SettingUpdateAction, dest=BuildSettings.OUTPUT.key, nargs=1, help="output folder for generated files"
        )
        lgroup = parser.add_mutually_exclusive_group()
        lgroup.add_argument(
            "--no-license", action=SettingUpdateAction, dest=BuildSettings.LICENSE_NONE.key, const="1", help="build leaf packages without license dependency"
        )
        lgroup.add_argument(
            "--license",
            metavar="LICENSE",
            action=SettingUpdateAction,
            dest=BuildSettings.LICENSE_NAME.key,
            nargs=1,
            help="build leaf packages with dependency on the specified LICENSE package",
        )
        parser.add_argument(
            "-t",
            "--tag",
            action=SettingUpdateAction,
            dest=BuildSettings.EXTRA_TAGS.key,
            nargs=argparse.ONE_OR_MORE,
            const=",",
            metavar="TAG",
            help="add TAG to built leaf package",
        )
        parser.add_argument(
            "--index-tag",
            action=SettingUpdateAction,
            dest=BuildSettings.INDEX_TAGS.key,
            nargs=argparse.ONE_OR_MORE,
            const=",",
            metavar="TAG",
            help="add TAG to leaf package when building index",
        )
        parser.add_argument(
            "--info", action=SettingUpdateAction, dest=BuildSettings.INFO.key, const="1", help="generate .info files on package build (for faster indexing)"
        )
        parser.add_argument(
            "--module",
            metavar="MODULE",
            action=SettingUpdateAction,
            dest=BuildSettings.MODULE.key,
            nargs=1,
            help="module ID to use in package name (inherited from LEGATO_TARGET by default)",
        )
        parser.add_argument(
            "--description",
            metavar="STRING",
            action=SettingUpdateAction,
            dest=BuildSettings.INDEX_DESCR.key,
            nargs=1,
            help="use STRING as generated leaf packages index description",
        )

        # Add builder custom arguments
        self.builder.add_options(parser)

    def execute(self, args, uargs):
        # Contribute plugin path to env
        BuildSettings.SCRIPTS_ROOT.value = str(self.installed_package.folder / "scripts")

        # Setup managers
        wm = self.get_workspacemanager()
        self.bm = BuildManager(wm, self.builder)
        self.builder.setup(self.bm)

        # Default output folder
        if not BuildSettings.OUTPUT.is_set():
            BuildSettings.OUTPUT.value = str(wm.ws_root_folder / "leaf")

        # Check enabled tasks
        self.enabled_tasks = {}
        for task in args.tasks:
            if task not in self.tasks.keys():
                raise UnknownBuildTaskException(task, self.name)
            self.enabled_tasks[task] = self.tasks[task]

        # Handle license check args if necessary
        if self.contains_task(PackBuildTask, self.enabled_tasks.values()):
            lpname = BuildSettings.LICENSE_NAME.value

            # No license info?
            if not BuildSettings.LICENSE_NONE.is_set() and lpname is None:
                raise LicenseInfoException()

            # Does the specified license package exist?
            if lpname is not None:
                license_pi = PackageIdentifier.parse(lpname)
                available_pis = self.bm.wm.list_available_packages().keys()
                if is_latest_package(license_pi):
                    license_pi = find_latest_version(license_pi, available_pis, ignore_unknown=True)
                if license_pi is None or license_pi not in available_pis:
                    raise UnknownLicenseException(lpname)

        # Ask for builder if it has some extra checks to perform
        self.builder.check_options(args, self.enabled_tasks)

        # Go for build
        self.bm.build(self.enabled_tasks)
