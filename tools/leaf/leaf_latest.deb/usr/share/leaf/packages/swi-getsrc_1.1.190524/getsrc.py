"""
Leaf Package Manager

@author:    Legato Tooling Team <letools@sierrawireless.com>
@copyright: Sierra Wireless. All rights reserved.
@contact:   Legato Tooling Team <letools@sierrawireless.com>
@license:   https://www.mozilla.org/en-US/MPL/2.0/
"""
import argparse

from leaf.api import WorkspaceManager
from leaf.cli.cliutils import init_common_args
from leaf.cli.plugins import LeafPluginCommand
from leaf.core.error import LeafException, WorkspaceNotInitializedException
from leaf.core.settings import EnvVar
from leaf.model.base import Scope


class GetSrcConstants:
    SRC_MODE_PATTERN = ".source.mode"
    BINARY = "binary"
    TAG = "tag"


class GetSrcContext:
    def __init__(self, args=None):
        self.__args = args
        self.__wm = WorkspaceManager(WorkspaceManager.find_root(check_parents=True))
        self.__module = EnvVar("LEAF_GETSRC_MODULE")
        if args is not None:
            if args.module is not None and not self.__wm.is_initialized:
                raise WorkspaceNotInitializedException()
            if args.module is None or args.module in self.known_modules:
                # Exact match or not specified
                self.__module.value = args.module
            else:
                # Short list modules from provided pattern: pick if only one matching module
                candidates = list(filter(lambda id: args.module in id, self.known_modules))
                if len(candidates) == 0:
                    raise LeafException(message="Unknown source module: " + args.module, hints=["Try 'leaf getsrc' to list available modules"])
                elif len(candidates) > 1:
                    raise LeafException(
                        message='Several candidate source modules for pattern "{m}"'.format(m=args.module),
                        hints=["Pick exactly one of the matching modules: {c}".format(c=", ".join(candidates))],
                    )
                self.__module.value = candidates[0]

    @property
    def wm(self):
        return self.__wm

    @property
    def args(self):
        return self.__args

    @property
    def scope(self):
        return self.__args.env_scope if self.__args.env_scope is not None else Scope.PROFILE

    @property
    def known_modules(self):
        return list(
            map(
                lambda x: x[: -len(GetSrcConstants.SRC_MODE_PATTERN)],
                filter(lambda n: n.endswith(GetSrcConstants.SRC_MODE_PATTERN), self.wm.get_settings().keys()),
            )
        )

    @property
    def module(self):
        return self.__module.value


def complete_getsrc_modules(*args, **kwargs):
    return GetSrcContext().known_modules


class GetSrcPlugin(LeafPluginCommand):
    def _configure_parser(self, parser):
        super()._configure_parser(parser)
        parser.add_argument(
            "module",
            nargs=argparse.OPTIONAL,
            metavar="SRCMODULE_PATTERN",
            help="pattern to select the module from which to trigger source sync\nif not specified, list available modules",
        ).completer = complete_getsrc_modules
        group = parser.add_mutually_exclusive_group()
        group.add_argument(
            "--binary",
            "--disable",
            dest="required_status",
            action="store_const",
            const=GetSrcConstants.BINARY,
            help="disable source mode and get back to binary mode",
        )
        group.add_argument(
            "--source", dest="required_status", action="store", metavar="MODE", help="toggle source mode in the specified MODE and trigger source sync"
        )
        init_common_args(parser, with_scope=True)

    def get_setting_id(self, ctx: GetSrcContext):
        return ctx.module + GetSrcConstants.SRC_MODE_PATTERN

    def get_profile(self, ctx: GetSrcContext):
        return ctx.wm.get_profile(ctx.wm.current_profile_name)

    def get_setting_value(self, ctx: GetSrcContext):
        return ctx.wm.get_setting_value(self.get_setting_id(ctx))

    def set_setting_value(self, ctx: GetSrcContext, value: str):
        ctx.wm.set_setting(self.get_setting_id(ctx), value, scope=ctx.scope)

    def reset_setting(self, ctx: GetSrcContext):
        ctx.wm.unset_setting(self.get_setting_id(ctx))

    def sync_module(self, ctx: GetSrcContext):
        # Check for current status
        current_status = self.get_setting_value(ctx)
        ctx.wm.logger.print_verbose("Current status for {m} module: {s}".format(m=ctx.module, s=current_status))

        # Determine new required status
        new_status = None
        if ctx.args.required_status is not None:
            new_status = ctx.args.required_status
        elif current_status is None:
            # No status arg specified, but currently in binary mode: default toggle to source (tag) mode
            new_status = GetSrcConstants.TAG

        # Different value?
        if new_status is not None and current_status != new_status:
            ctx.wm.logger.print_verbose("Toggling status for {m} module: {s}".format(m=ctx.module, s=new_status))
            if new_status == GetSrcConstants.BINARY:
                self.reset_setting(ctx)
            else:
                self.set_setting_value(ctx, new_status)

        # In any case, finally trigger a profile sync
        ctx.wm.provision_profile(self.get_profile(ctx))

    def execute(self, args, uargs):
        ctx = GetSrcContext(args)
        if ctx.module is None:
            # Just list available modules
            ctx.wm.logger.print_quiet("\n".join(ctx.known_modules))
        else:
            # Something to sync
            self.sync_module(ctx)
