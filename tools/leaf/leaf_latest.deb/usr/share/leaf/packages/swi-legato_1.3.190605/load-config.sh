# Wrapper to Legato config.sh script

# Only go further if Legato config.sh exists
if test -e "$LEGATO_CONFIG_SCRIPT"; then
    # Load Legato config
    source "$LEGATO_CONFIG_SCRIPT"
fi
