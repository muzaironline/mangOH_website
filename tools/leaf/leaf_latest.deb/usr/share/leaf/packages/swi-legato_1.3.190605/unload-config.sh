# Wrapper to unload Legato config.sh script

# Only go further if Legato config.sh exists
if test -e "$LEGATO_CONFIG_SCRIPT"; then
    # Generate config unload script
    LEGATO_UNLOAD_CONFIG="$(mktemp)"
    cat "$LEGATO_CONFIG_SCRIPT" \
        | grep -E "^(export LE_CONFIG|# LE_CONFIG)" \
        | sed -e "s|export \(LE_CONFIG[^=]*\)=.*|unset \1|g;s|# \(LE_CONFIG[^ ]*\).*|unset \1|g" \
        > "${LEGATO_UNLOAD_CONFIG}"
    source "${LEGATO_UNLOAD_CONFIG}"
    if test -z "$LEAF_DEBUG"; then
        rm -f "${LEGATO_UNLOAD_CONFIG}"
        unset LEGATO_UNLOAD_CONFIG
    fi
fi
