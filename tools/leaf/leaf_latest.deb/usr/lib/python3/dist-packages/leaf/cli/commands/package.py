"""
Leaf Package Manager

@author:    Legato Tooling Team <letools@sierrawireless.com>
@copyright: Sierra Wireless. All rights reserved.
@contact:   Legato Tooling Team <letools@sierrawireless.com>
@license:   https://www.mozilla.org/en-US/MPL/2.0/
"""

import argparse
from builtins import ValueError
from collections import OrderedDict
from pathlib import Path
from string import Formatter

from leaf.api import PackageManager
from leaf.cli.base import LeafCommand
from leaf.cli.cliutils import get_optional_arg
from leaf.cli.completion import complete_all_packages, complete_available_packages, complete_installed_packages, complete_installed_packages_tags
from leaf.core.error import PackageInstallInterruptedException
from leaf.core.jsonutils import jtostring
from leaf.core.utils import env_list_to_map
from leaf.model.dependencies import DependencyUtils
from leaf.model.environment import Environment
from leaf.model.filtering import MetaPackageFilter
from leaf.model.package import IDENTIFIER_GETTER, LeafArtifact, PackageIdentifier
from leaf.rendering.renderer.manifest import ManifestListRenderer
from leaf.model.modelutils import group_package_identifiers_by_name


class PackageListCommand(LeafCommand):
    def __init__(self):
        LeafCommand.__init__(self, "list", "list installed packages")

    def _configure_parser(self, parser):
        super()._configure_parser(parser)
        parser.add_argument("-a", "--all", dest="show_all_packages", action="store_true", help="display all packages, not only master packages")
        parser.add_argument(
            "-t", "--tag", dest="tags", metavar="TAG", action="append", help="filter search results matching with given tag"
        ).completer = complete_installed_packages_tags
        parser.add_argument(
            "keywords", metavar="KEYWORD", nargs=argparse.ZERO_OR_MORE, help="filter with given keywords"
        ).completer = complete_installed_packages

    def execute(self, args, uargs):
        pm = PackageManager()
        metafilter = MetaPackageFilter()

        if not get_optional_arg(args, "show_all_packages", False):
            metafilter.only_master_packages()

        for t in get_optional_arg(args, "tags", []):
            metafilter.with_tag(t)

        for kw in get_optional_arg(args, "keywords", []):
            metafilter.with_keyword(kw)

        # Print filtered packages
        rend = ManifestListRenderer(metafilter)
        mflist = pm.list_installed_packages().values()
        rend.extend(filter(metafilter.matches, mflist))
        pm.print_renderer(rend)


class PackageDepsCommand(LeafCommand):
    def __init__(self):
        LeafCommand.__init__(self, "deps", "Build the dependency chain")

    def _configure_parser(self, parser):
        super()._configure_parser(parser)
        group = parser.add_mutually_exclusive_group()
        group.add_argument(
            "--installed",
            dest="dependency_type",
            action="store_const",
            const="installed",
            default="installed",
            help="build dependency list from installed packages",
        )
        group.add_argument("--available", dest="dependency_type", action="store_const", const="available", help="build dependency list from available packages")
        group.add_argument("--install", dest="dependency_type", action="store_const", const="install", help="build dependency list to install")
        group.add_argument("--uninstall", dest="dependency_type", action="store_const", const="uninstall", help="build dependency list to uninstall")
        group.add_argument("--prereq", dest="dependency_type", action="store_const", const="prereq", help="build dependency list for prereq install")
        group.add_argument("--upgrade", dest="dependency_type", action="store_const", const="upgrade", help="build dependency list for upgrade")
        group.add_argument(
            "--rdepends", dest="dependency_type", action="store_const", const="rdepends", help="list packages having given package(s) as dependency"
        )
        parser.add_argument("--env", dest="custom_envlist", action="append", metavar="KEY=VALUE", help="add given environment variable")
        parser.add_argument("packages", metavar="PKG_IDENTIFIER", nargs=argparse.ZERO_OR_MORE, help="package identifier").completer = complete_all_packages

    def execute(self, args, uargs):
        pm = PackageManager()
        env = None
        # If the user specified env values, build a complete env
        if args.custom_envlist is not None:
            env = Environment.build(
                pm.build_builtin_environment(), pm.build_user_environment(), Environment("Custom env", env_list_to_map(args.custom_envlist))
            )

        items = None
        if args.dependency_type == "available":
            items = DependencyUtils.install(PackageIdentifier.parse_list(args.packages), pm.list_available_packages(), {}, env=env)
        elif args.dependency_type == "install":
            items = DependencyUtils.install(PackageIdentifier.parse_list(args.packages), pm.list_available_packages(), pm.list_installed_packages(), env=env)
        elif args.dependency_type == "installed":
            items = DependencyUtils.installed(PackageIdentifier.parse_list(args.packages), pm.list_installed_packages(), env=env, ignore_unknown=True)
        elif args.dependency_type == "uninstall":
            items = DependencyUtils.uninstall(PackageIdentifier.parse_list(args.packages), pm.list_installed_packages(), env=env)
        elif args.dependency_type == "prereq":
            items = DependencyUtils.prereq(PackageIdentifier.parse_list(args.packages), pm.list_available_packages(), pm.list_installed_packages(), env=env)
        elif args.dependency_type == "upgrade":
            items, _ = DependencyUtils.upgrade(
                None if len(args.packages) == 0 else args.packages, pm.list_available_packages(), pm.list_installed_packages(), env=env
            )
        elif args.dependency_type == "rdepends":
            mfmap = OrderedDict()
            mfmap.update(DependencyUtils.rdepends(PackageIdentifier.parse_list(args.packages), pm.list_available_packages(), env=env))
            mfmap.update(DependencyUtils.rdepends(PackageIdentifier.parse_list(args.packages), pm.list_installed_packages(), env=env))
            items = mfmap.values()
        else:
            raise ValueError()

        rend = ManifestListRenderer()
        rend.extend(items)
        pm.print_renderer(rend)


class PackageInstallCommand(LeafCommand):
    def __init__(self):
        LeafCommand.__init__(self, "install", "install packages (download + extract)")

    def _configure_parser(self, parser):
        super()._configure_parser(parser)
        parser.add_argument("-k", "--keep", dest="keep_on_error", action="store_true", help="keep package folder in case of installation error")
        parser.add_argument(
            "packages", metavar="PKG_IDENTIFIER", nargs=argparse.ONE_OR_MORE, help="identifier of packages to install"
        ).completer = complete_available_packages

    def execute(self, args, uargs):
        pm = PackageManager()

        complete_available_packages()
        try:
            items = pm.install_packages(args.packages, keep_folder_on_error=args.keep_on_error)
        except Exception as e:
            raise PackageInstallInterruptedException(args.packages, e)

        if len(items) > 0:
            pm.logger.print_quiet("Packages installed:", " ".join([str(p.identifier) for p in items]))


class PackageUninstallCommand(LeafCommand):
    def __init__(self):
        LeafCommand.__init__(self, "uninstall", "remove packages")

    def _configure_parser(self, parser):
        super()._configure_parser(parser)
        parser.add_argument(
            "packages", metavar="PKG_IDENTIFIER", nargs=argparse.ONE_OR_MORE, help="identifier of package to uninstall"
        ).completer = complete_installed_packages

    def execute(self, args, uargs):
        pm = PackageManager()

        pm.uninstall_packages(PackageIdentifier.parse_list(args.packages))


class PackageSyncCommand(LeafCommand):
    def __init__(self):
        LeafCommand.__init__(self, "sync", "performs sync operation")

    def _configure_parser(self, parser):
        super()._configure_parser(parser)
        parser.add_argument(
            "packages", metavar="PKGNAME", nargs=argparse.ONE_OR_MORE, help="name of package to uninstall"
        ).completer = complete_installed_packages

    def execute(self, args, uargs):
        pm = PackageManager()

        pm.sync_packages(PackageIdentifier.parse_list(args.packages))


class PackageUpgradeCommand(LeafCommand):
    def __init__(self):
        LeafCommand.__init__(self, "upgrade", "upgrade packages to latest version")

    def _configure_parser(self, parser):
        super()._configure_parser(parser)
        parser.add_argument("--clean", dest="clean", action="store_true", help="also try to uninstall old versions of upgraded packages")
        parser.add_argument(
            "packages", metavar="PKGNAME", nargs=argparse.ZERO_OR_MORE, help="name of the packages to upgrade"
        ).completer = complete_installed_packages

    def execute(self, args, uargs):
        pm = PackageManager()
        wm = self.get_workspacemanager()
        profilename = wm.current_profile_name
        profile = wm.get_profile(profilename)

        env = Environment.build(pm.build_builtin_environment(), pm.build_user_environment())

        install_list, upgraded_list = DependencyUtils.upgrade(
            None if len(args.packages) == 0 else args.packages, pm.list_available_packages(), pm.list_installed_packages(), env=env
        )

        pm.logger.print_verbose(
            "{count} package(s) to be upgraded: {text}".format(count=len(install_list), text=" ".join([str(ap.identifier) for ap in install_list]))
        )
        if args.clean:
            pm.logger.print_verbose(
                "{count} package(s) to be removed: {text}".format(count=len(upgraded_list), text=" ".join([str(ip.identifier) for ip in upgraded_list]))
            )

        if len(install_list) == 0:
            pm.logger.print_default("No package to upgrade")
        else:
            pm.install_packages(map(IDENTIFIER_GETTER, install_list), env=env)
            if len(upgraded_list) > 0:
                if args.clean:
                    pm.uninstall_packages(map(IDENTIFIER_GETTER, upgraded_list))
                else:
                    pm.logger.print_default("Packages upgraded:", " ".join(
                        [str(ip.identifier) for ip in upgraded_list]))
                    pm.logger.print_default(
                        'Hint: Use "leaf profile config -p {PACKAGENAME}" to add these packages to your workspace profile')

        update_pilist = install_list
        profile_pkg_map = profile.pkg_map

        installed_packages = group_package_identifiers_by_name(wm.list_installed_packages())
        pkg_list = args.packages if args.packages else profile_pkg_map.keys()

        for pkg in pkg_list:
            pi = None
            if pkg in installed_packages.keys():
                # Get latest version
                pi = installed_packages[pkg][-1]

            if pi is not None and pi not in update_pilist:
                # Get PI in profile
                previous_pi = PackageIdentifier(pi.name, profile_pkg_map[pi.name]) if pi.name in profile_pkg_map else None
                if previous_pi is None:
                    # Package is not in profile yet, add it
                    update_pilist.append(pi)
                elif previous_pi != pi:
                    # Package is already in profile with a different version, update it
                    update_pilist.append(pi)
                else:
                    # Package is already in profile with same version, do nothing
                    pass

        if len(update_pilist) == 0:
            pm.logger.print_default("Packages are already in profile with same version")
        else:
            pm.logger.print_default("Packages to be updated in profile:", " ".join([str(pi) for pi in update_pilist]))
            profile.add_packages(update_pilist)
            wm.update_profile(profile)


class PackageInspectCommand(LeafCommand):
    def __init__(self):
        LeafCommand.__init__(self, "inspect", "display information about packages")

    def _get_examples(self):
        return [
            ("leaf package inspect package.leaf", "To display all fields of the manifest.json 'info' node "),
            ("leaf package inspect --format json package.leaf", "To display the 'info' node of the manifest.json"),
            ("leaf package inspect --format 'my package {name} @ {version} -> {depends}' package.leaf", "To print custom formatted strings"),
        ]

    def _configure_parser(self, parser):
        parser.add_argument(
            "-f",
            "--format",
            help="output format, can be 'json' to get the raw json content or any string containing fields of the 'info' node, example: 'Name:{name} at version {version} ({description})'",
        )
        parser.add_argument("files", metavar="LEAF_FILE", type=Path, nargs=argparse.ONE_OR_MORE, help="files to inspect")

    def execute(self, args, uargs):
        def tostring(item):
            if item is None:
                return ""
            if isinstance(item, (list, tuple)):
                return ", ".join(map(tostring, item))
            if isinstance(item, dict):
                return tostring(list(map(lambda kv: "{0}={1}".format(kv[0], kv[1]), item.items())))
            return str(item)

        for index in range(0, len(args.files)):
            if index > 0:
                print("")
            file = args.files[index]
            try:
                la = LeafArtifact(file)
                if args.format is None:
                    print(file)
                    kvfmt = "  {k}: {v}"
                    print(kvfmt.format(k="identifier", v=la.identifier))
                    print(kvfmt.format(k="name", v=la.name))
                    print(kvfmt.format(k="version", v=la.version))
                    for k, v in la.info_node.items():
                        if k not in ("name", "version"):
                            print(kvfmt.format(k=k, v=tostring(v)))
                elif args.format == "json":
                    print(jtostring(la.info_node, pp=True))
                else:

                    class MyFormatter(Formatter):
                        def __init__(self, la, *args, **kwargs):
                            Formatter.__init__(self, *args, **kwargs)

                        def get_value(self, key, args, kwargs):
                            return tostring(la.info_node.get(key))

                    print(MyFormatter(la).format(args.format))
            except BaseException as e:
                print("Invalid leaf file {f}: {e}".format(f=file, e=e))
