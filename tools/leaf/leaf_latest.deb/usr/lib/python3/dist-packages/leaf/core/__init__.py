import os

REFERENCE_ENVIRON = dict(os.environ)
